<?php
/* Generado por construir.py desde reglas.txt – no editar a mano */
if ( ! defined( 'ABSPATH' ) ) { exit; }
return array(
	array( 'Payroc', 'No se menciona al procesador en la web' ),
	array( 'RewardPay|ConsumerChoice|RocTerminal', 'Nombres de programas del procesador' ),
	array( '\\bJCF\\b', 'La marca anterior no va en la web' ),
	array( '\\bAurora\\b', 'La zona pública es todo Illinois' ),
	array( '\\bToast\\b|\\bShift4\\b|\\bSquare\\b', 'No se nombran competidores' ),
	array( 'pr[ée]stamo|\\bloans?\\b', 'Decir financiamiento, no préstamo' ),
	array( 'm[áa]s de \\$30,000 en ventas|over \\$30,000 in monthly sales', 'La cifra de la terminal gratis no se publica' ),
	array( 'hasta (un )?100 ?%|100 ?% de ahorro|ahorro del 100|garantizad|guaranteed', 'Promesas de ahorro no permitidas' ),
	array( 'el m[áa]s barato|the cheapest', 'Comparación de precio no permitida' ),
	array( 'hasta (un )?70 ?%|10-30 ?%', 'Cifras de folletos de terceros' ),
	array( 'POR CONFIRMAR', 'Quedó un texto sin confirmar' )
);
