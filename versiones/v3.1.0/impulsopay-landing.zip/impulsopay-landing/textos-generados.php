<?php
/* Generado por construir.py – no editar a mano */
if ( ! defined( 'ABSPATH' ) ) { exit; }
return array( 'es' => array( 'testiEyebrow' => 'Testimonios', 'testiTitle' => 'Lo que dicen nuestros clientes', 'promoLink' => 'Más información' ), 'en' => array( 'testiEyebrow' => 'Testimonials', 'testiTitle' => 'What our clients say', 'promoLink' => 'Learn more' ) );
