<?php
/**
 * Plantilla de la landing de Impulso Pay.
 * Los textos en ESPAÑOL se editan aquí. Los textos en INGLÉS, el horario, el cargo,
 * el endpoint del formulario y el modo borrador se editan en assets/landing.js.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
?><!doctype html>
<html lang="es">
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#083D78">
<?php if ( ! has_site_icon() ) : ?>
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect width='32' height='32' rx='7' fill='%23083D78'/%3E%3Cpath d='M8 23 L22 10' stroke='%2375C532' stroke-width='4' stroke-linecap='round'/%3E%3Cpath d='M15 9 H23 V17' fill='none' stroke='%2375C532' stroke-width='4' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E">
<?php endif; ?>
<?php if ( ! defined( 'WPSEO_VERSION' ) && ! defined( 'RANK_MATH_VERSION' ) ) : /* Solo si no hay plugin de SEO */ ?>
<meta name="description" content="Merchant Services en Illinois: sistemas POS Clover, procesamiento de tarjetas, Cash Discount, Dual Pricing y financiamiento para negocios. Atención 24/7 en español e inglés. Llama al 630-551-6701.">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Impulso Pay">
<meta property="og:title" content="Impulso Pay | Impulsa tu negocio. Simplifica tus pagos.">
<meta property="og:description" content="Sistemas POS Clover y procesamiento de tarjetas con atención directa 24/7, en español e inglés, en todo Illinois.">
<meta property="og:url" content="<?php echo esc_url( home_url( '/' ) ); ?>">
<meta property="og:image" content="<?php echo esc_url( IPL_URL . 'assets/logo.webp' ); ?>">
<meta property="og:locale" content="es_US">
<meta name="twitter:card" content="summary_large_image">
<?php endif; ?>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "name": "Impulso Pay",
  "slogan": "Impulsa tu negocio. Simplifica tus pagos.",
  "description": "Merchant Services: sistemas POS Clover y procesamiento de tarjetas para restaurantes, tiendas y pequeños negocios. Atención 24/7 en español e inglés.",
  "url": "https://impulsopay.com/",
  "telephone": "+1-630-551-6701",
  "email": "jose.colindres@impulsopay.com",
  "image": "https://impulsopay.com/logo.png",
  "knowsLanguage": ["es", "en"],
  "openingHours": "Mo-Su 00:00-23:59",
  "areaServed": [
    { "@type": "State", "name": "Illinois" },
    { "@type": "State", "name": "Wisconsin" },
    { "@type": "State", "name": "Indiana" },
    { "@type": "State", "name": "Texas" },
    { "@type": "State", "name": "Kentucky" },
    { "@type": "Country", "name": "United States" }
  ],
  "founder": { "@type": "Person", "name": "José Colindres" }
}
</script>
<?php wp_head(); ?>
</head>
<body <?php body_class( 'ipl-landing' ); ?>>
<?php wp_body_open(); ?>
<a class="skip" href="#principal" data-i18n="skip">Saltar al contenido</a>
<div class="borrador-aviso" id="avisoBorrador" hidden data-i18n="draftBanner">Modo borrador: lo marcado con [PENDIENTE] no se publica hasta que esté aprobado.</div>

<!-- 1. BARRA SUPERIOR -->
<div class="topbar oscuro">
  <div class="wrap">
    <div class="links">
      <a href="tel:+16305516701" data-track="call">
        <svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2z"/></svg>
        <span>630-551-6701</span>
      </a>
      <a href="https://wa.me/16305516701" target="_blank" rel="noopener" data-track="whatsapp">
        <svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 11.5a8.4 8.4 0 0 1-12.4 7.4L3 21l2.1-5.4A8.4 8.4 0 1 1 21 11.5z"/></svg>
        <span>WhatsApp</span>
      </a>
    </div>
    <div class="lang" role="group" aria-label="Idioma / Language">
      <button type="button" data-lang="es" aria-pressed="true" lang="es">ES</button>
      <button type="button" data-lang="en" aria-pressed="false" lang="en">EN</button>
    </div>
  </div>
</div>

<?php ipl_render_promo(); ?>
<header class="site">
  <div class="wrap">
    <a class="marca" href="#principal" aria-label="Impulso Pay, inicio">
      <!-- LOGO: reemplazar por /logo-impulsopay.svg cuando exista la versión vectorial -->
      <img src="<?php echo esc_url( IPL_URL . 'assets/wordmark.webp' ); ?>" width="560" height="75" alt="Impulso Pay">
      <span data-i18n="tagline">Impulsa tu negocio. Simplifica tus pagos.</span>
    </a>
    <nav aria-label="Secciones">
      <a href="#como" data-i18n="navHow">Cómo funciona</a>
      <a href="#equipos" data-i18n="navSystems">Sistemas POS</a>
      <a href="#precio-dual" data-i18n="navDual" data-claim="cero_cargo" data-nobadge>Cash Discount</a>
      <?php if ( ipl_mostrar( 'financiamiento' ) ) : ?><a href="#financiamiento" data-i18n="navFund">Financiamiento</a><?php endif; ?>
      <?php if ( ipl_mostrar( 'servicios' ) ) : ?><a href="#servicios" data-i18n="navSrv">Servicios</a><?php endif; ?>
      <a href="#preguntas" data-i18n="navFaq">Preguntas</a>
    </nav>
    <a class="btn btn-prim btn-sm" href="#contacto" data-i18n="headerCta">Análisis GRATIS</a>
  </div>
</header>

<main id="principal">

<!-- 2. HERO -->
<section class="hero" aria-labelledby="h-hero">
  <svg class="trazo" viewBox="0 0 1200 600" preserveAspectRatio="none" aria-hidden="true">
    <defs><linearGradient id="gF" x1="0" y1="1" x2="1" y2="0"><stop offset="0" stop-color="#4CAF32" stop-opacity="0"/><stop offset=".55" stop-color="#4CAF32" stop-opacity=".35"/><stop offset="1" stop-color="#75C532" stop-opacity=".55"/></linearGradient></defs>
    <path d="M-20 560 C 300 520, 640 420, 1220 60" stroke="url(#gF)" stroke-width="16"/>
    <path d="M-20 590 C 340 560, 700 470, 1220 150" stroke="#0163BA" stroke-opacity=".08" stroke-width="40"/>
  </svg>
  <div class="wrap">
    <div class="hero-txt">
      <p class="eyebrow" data-i18n="heroEyebrow">Merchant Services · Illinois</p>
      <h1 id="h-hero" data-i18n="heroTitle">Acepta pagos con tarjeta de manera <em>fácil, rápida y segura.</em></h1>
      <p class="lead" data-i18n="heroLead">Sistemas POS Clover y procesamiento de tarjetas (credit card processing) para restaurantes, tiendas y pequeños negocios, con atención directa de José 24/7, en español o en inglés.</p>
      <div class="acciones">
        <a class="btn btn-prim" href="tel:+16305516701" data-track="call">
          <svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2z"/></svg>
          <span data-i18n="ctaCall">Llamar ahora</span>
        </a>
        <a class="btn btn-sec" href="https://wa.me/16305516701" target="_blank" rel="noopener" data-track="whatsapp">
          <svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 11.5a8.4 8.4 0 0 1-12.4 7.4L3 21l2.1-5.4A8.4 8.4 0 1 1 21 11.5z"/></svg>
          <span data-i18n="ctaWa">Escribir por WhatsApp</span>
        </a>
      </div>
      <p class="num"><span data-i18n="heroNum">Teléfono y WhatsApp:</span> <strong>630-551-6701</strong> · <span data-i18n="hoursLabel">Horario:</span> <span data-config="HORARIO"></span></p>
    </div>
    <div class="hero-visual">
      <!-- LOGO: los bordes del PNG son aceptables a este tamaño; reemplazar por SVG cuando exista -->
      <img src="<?php echo esc_url( IPL_URL . 'assets/logo.webp' ); ?>" width="640" height="426" alt="Logotipo de Impulso Pay">
      <p class="lema" data-i18n="heroLema">Impulsa tu negocio. <b>Simplifica tus pagos.</b></p>
    </div>
  </div>
</section>

<!-- 3. FRANJA DE CONFIANZA (solo hechos) -->
<div class="confianza oscuro" aria-label="Por qué Impulso Pay">
  <ul class="wrap">
    <li><svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"/></svg><span data-i18n="t1">Atención personal 24/7</span></li>
    <li><svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" aria-hidden="true"><path d="M12 22s7-6.2 7-12a7 7 0 0 0-14 0c0 5.8 7 12 7 12z"/><circle cx="12" cy="10" r="2.5"/></svg><span data-i18n="t2">Atención en todo Illinois</span></li>
    <li><svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" aria-hidden="true"><path d="M4 5h9M8.5 3v2M6 5c.5 3 2.5 5.5 5 7M11 5c-.8 3.5-3.3 6.5-6.5 8"/><path d="M13 21l4-10 4 10M14.5 17h5"/></svg><span data-i18n="t3">Español e inglés</span></li>
    <li><svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" aria-hidden="true"><rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8M12 17v4"/></svg><span data-i18n="t4">Sistemas POS Clover</span></li>
    <li><svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg><span data-i18n="t5">Instalación, capacitación y soporte continuo</span></li>
  </ul>
</div>

<!-- 4. PROBLEMA → SOLUCIÓN -->
<section class="sec" aria-labelledby="h-prob">
  <div class="wrap">
    <div class="cab">
      <p class="eyebrow" data-i18n="probEyebrow">Lo que escuchamos de los dueños</p>
      <h2 id="h-prob" data-i18n="probTitle">Procesar tarjetas no tiene por qué ser complicado</h2>
    </div>
    <div class="pares">
      <div class="par">
        <div class="antes"><s data-i18n="p1a">Comisiones que no sabes de dónde salen</s></div>
        <div class="despues"><svg class="flecha" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 19 19 5M10 5h9v9"/></svg><span data-i18n="p1b">Te explicamos cada cargo, línea por línea, antes de que firmes.</span></div>
      </div>
      <div class="par">
        <div class="antes"><s data-i18n="p2a">Estados de cuenta largos y difíciles de leer</s></div>
        <div class="despues"><svg class="flecha" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 19 19 5M10 5h9v9"/></svg><span data-i18n="p2b">Te damos un análisis GRATIS de tus costos de procesamiento y te mostramos exactamente qué estás pagando.</span></div>
      </div>
      <div class="par">
        <div class="antes"><s data-i18n="p3a">Soporte lento o un número donde nadie contesta</s></div>
        <div class="despues"><svg class="flecha" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 19 19 5M10 5h9v9"/></svg><span data-i18n="p3b">Llamas o escribes a José directamente, 24/7, y él da seguimiento en persona.</span></div>
      </div>
    </div>
    <div class="estado-cuenta">
      <h3 data-i18n="ecTitle">¿Te suenan estos términos de tu estado de cuenta?</h3>
      <ul class="terminos" aria-label="Términos comunes">
        <li>Interchange</li><li>Assessment fee</li><li>Batch fee</li><li>PCI fee</li><li>Statement fee</li><li>Monthly minimum</li>
      </ul>
      <p data-i18n="ecText">Son nombres comunes en un estado de cuenta de procesamiento. Tráenos el tuyo y te explicamos qué significa cada uno en tu caso.</p>
    </div>
  </div>
</section>

<!-- 5. CÓMO FUNCIONA -->
<section class="sec sec-suave" id="como" aria-labelledby="h-como">
  <div class="wrap">
    <div class="cab">
      <p class="eyebrow" data-i18n="howEyebrow">Cómo funciona</p>
      <h2 id="h-como" data-i18n="howTitle">Tu negocio en marcha en 4 sencillos pasos</h2>
    </div>
    <ol class="pasos">
      <li class="paso"><span class="n" aria-hidden="true">1</span><h3 data-i18n="s1t">Consulta</h3><p data-i18n="s1d">Llamas o escribes. Hablamos de tu negocio, cómo aceptas pagos hoy y qué necesitas.</p></li>
      <li class="paso"><span class="n" aria-hidden="true">2</span><h3 data-i18n="s2t">Análisis GRATIS de tus costos de procesamiento</h3><p data-i18n="s2d">Revisamos tu estado de cuenta (statement) y lo que pagas hoy, y te damos una propuesta por escrito, sin compromiso.</p></li>
      <li class="paso"><span class="n" aria-hidden="true">3</span><h3 data-i18n="s3t">Instalación y capacitación</h3><p data-i18n="s3d">José va a tu negocio, instala el equipo y te enseña a usarlo a ti y a tu personal.</p></li>
      <li class="paso"><span class="n" aria-hidden="true">4</span><h3 data-i18n="s4t">Soporte continuo</h3><p data-i18n="s4d">Seguimos en contacto después de instalar. Si algo falla, llamas al mismo número, 24/7.</p></li>
    </ol>
  </div>
</section>

<!-- 6. TERMINALES Y SISTEMAS POS CLOVER (solo texto; sin logos ni fotos de producto. Datos tomados de las fichas oficiales) -->
<section class="sec" id="equipos" aria-labelledby="h-eq">
  <div class="wrap">
    <div class="cab" data-claim="clover_texto">
      <p class="eyebrow" data-i18n="eqEyebrow">Terminales y sistemas POS</p>
      <h2 id="h-eq" data-i18n="eqTitle">Sistemas POS y terminales para cada tipo de negocio</h2>
      <p data-i18n="eqLead">Trabajamos con sistemas Clover y con la terminal Newland N950. Desde una terminal de mostrador hasta un kiosco de autoservicio, te recomendamos el equipo según cómo atiendes a tus clientes y te damos los precios por escrito.</p>
    </div>
    <div class="filtro" role="group" aria-labelledby="filtro-lbl">
      <span class="filtro-lbl" id="filtro-lbl" data-i18n="fitLbl">¿Qué tipo de negocio tienes?</span>
      <button type="button" data-fit="todos" aria-pressed="true" data-i18n="fitAll">Todos</button>
      <button type="button" data-fit="restaurante" aria-pressed="false" data-i18n="fitRest">Restaurante</button>
      <button type="button" data-fit="rapida" aria-pressed="false" data-i18n="fitQsr">Comida rápida</button>
      <button type="button" data-fit="tienda" aria-pressed="false" data-i18n="fitRetail">Tienda o joyería</button>
      <button type="button" data-fit="servicios" aria-pressed="false" data-i18n="fitSalon">Salón o servicios</button>
      <button type="button" data-fit="taller" aria-pressed="false" data-i18n="fitShop">Taller</button>
    </div>
    <p class="desliza" data-i18n="swipe">Desliza para ver todos los equipos →</p>
    <div class="equipos" data-claim="clover_modelos">
      <article class="equipo" data-fit="servicios,taller,tienda">
        <div class="eq-foto"><img src="<?php echo esc_url( IPL_URL . 'assets/prod/compact.webp' ); ?>" alt="Clover Compact"></div>
        <div class="eq-top"><span class="tipo" data-i18n="eq_compact_tipo">Mostrador · Solo cobros</span><span class="reco" data-i18n="reco">Recomendado</span></div>
        <h3>Clover Compact</h3>
        <p data-i18n="eq_compact_d">Terminal de pagos para el mostrador, pensada para cobrar rápido y sin complicaciones.</p>
        <ul data-i18n="eq_compact_l"><li>Pantalla táctil de 3.6" y teclado PIN físico</li><li>Impresora térmica integrada</li><li>Chip, contactless y banda magnética</li><li>Wi-Fi, LAN y LTE</li></ul>
        <p class="ideal" data-i18n="eq_compact_i"><b>Ideal para:</b> salones, talleres y negocios que solo necesitan cobrar.</p>
      </article>
      <article class="equipo" data-fit="tienda,servicios,rapida">
        <div class="eq-foto"><img src="<?php echo esc_url( IPL_URL . 'assets/prod/mini.webp' ); ?>" alt="Clover Mini"></div>
        <div class="eq-top"><span class="tipo" data-i18n="eq_mini_tipo">Mostrador · POS completo</span><span class="reco" data-i18n="reco">Recomendado</span></div>
        <h3>Clover Mini</h3>
        <p data-i18n="eq_mini_d">Un punto de venta completo en un equipo pequeño, para liberar espacio en tu caja.</p>
        <ul data-i18n="eq_mini_l"><li>Pantalla táctil de 7" e impresora de recibos integrada</li><li>Chip, contactless y banda magnética</li><li>Inventario con categorías, modificadores y variantes</li><li>Ethernet, Wi-Fi, Bluetooth y 4G</li></ul>
        <p class="ideal" data-i18n="eq_mini_i"><b>Ideal para:</b> tiendas, joyerías, cafeterías y salones.</p>
      </article>
      <article class="equipo" data-fit="restaurante,taller,tienda">
        <div class="eq-foto"><img src="<?php echo esc_url( IPL_URL . 'assets/prod/flex.webp' ); ?>" alt="Clover Flex"></div>
        <div class="eq-top"><span class="tipo" data-i18n="eq_flex_tipo">Portátil · Con impresora</span><span class="reco" data-i18n="reco">Recomendado</span></div>
        <h3>Clover Flex</h3>
        <p data-i18n="eq_flex_d">POS de mano para cobrar donde está el cliente, con la misma capacidad que un equipo grande.</p>
        <ul data-i18n="eq_flex_l"><li>Pantalla táctil de 5.99" e impresora integrada</li><li>Wi-Fi y 4G/LTE con batería de litio</li><li>Inicio de sesión con huella digital</li><li>Swipe, chip, tap y billeteras móviles</li></ul>
        <p class="ideal" data-i18n="eq_flex_i"><b>Ideal para:</b> pago en la mesa, filas, ventas en la acera y eventos.</p>
      </article>
      <article class="equipo" data-fit="restaurante">
        <div class="eq-foto"><img src="<?php echo esc_url( IPL_URL . 'assets/prod/pocket.webp' ); ?>" alt="Clover Flex Pocket"></div>
        <div class="eq-top"><span class="tipo" data-i18n="eq_pocket_tipo">Portátil · Ultraligero</span><span class="reco" data-i18n="reco">Recomendado</span></div>
        <h3>Clover Flex Pocket</h3>
        <p data-i18n="eq_pocket_d">La versión más ligera del Flex. Cabe en el bolsillo o en el delantal.</p>
        <ul data-i18n="eq_pocket_l"><li>Pantalla de 6" y escáner de códigos de barras y QR</li><li>Pesa 0.9 lb (el Flex 3 pesa 1.2 lb)</li><li>Recibos por email o SMS (no trae impresora)</li><li>Envía las órdenes desde la mesa</li></ul>
        <p class="ideal" data-i18n="eq_pocket_i"><b>Ideal para:</b> meseros y servicio a la mesa.</p>
      </article>
      <article class="equipo" data-fit="restaurante,tienda,servicios">
        <div class="eq-foto"><img src="<?php echo esc_url( IPL_URL . 'assets/prod/solo.webp' ); ?>" alt="Clover Station Solo"></div>
        <div class="eq-top"><span class="tipo" data-i18n="eq_solo_tipo">Estación completa</span><span class="reco" data-i18n="reco">Recomendado</span></div>
        <h3>Clover Station Solo</h3>
        <p data-i18n="eq_solo_d">POS de pantalla grande para manejar todo tu negocio desde un solo sistema.</p>
        <ul data-i18n="eq_solo_l"><li>Clover Dining: salón y cocina sincronizados</li><li>Inventario, devoluciones y cambios</li><li>Reportes de ventas y manejo de empleados</li><li>Pedidos en línea (online ordering)</li></ul>
        <p class="ideal" data-i18n="eq_solo_i"><b>Ideal para:</b> restaurantes con mucho movimiento y tiendas con varios empleados.</p>
      </article>
      <article class="equipo" data-fit="restaurante,tienda,rapida">
        <div class="eq-foto"><img src="<?php echo esc_url( IPL_URL . 'assets/prod/duo.webp' ); ?>" alt="Clover Station Duo"></div>
        <div class="eq-top"><span class="tipo" data-i18n="eq_duo_tipo">Estación completa · Dos pantallas</span><span class="reco" data-i18n="reco">Recomendado</span></div>
        <h3>Clover Station Duo</h3>
        <p data-i18n="eq_duo_d">POS completo con una pantalla para ti y otra para tu cliente, para que vea su cuenta y pague desde su lado.</p>
        <ul data-i18n="eq_duo_l"><li>Pantalla para el cliente: paga sin contacto y deja sus datos y preferencias</li><li>Clover Dining: salón y cocina sincronizados</li><li>Inventario, devoluciones y cambios</li><li>Reportes de ventas y manejo de empleados</li></ul>
        <p class="ideal" data-i18n="eq_duo_i"><b>Ideal para:</b> restaurantes y tiendas con mucho movimiento que quieren una caja más ágil.</p>
      </article>
      <article class="equipo" data-fit="rapida">
        <div class="eq-foto eq-foto-cover"><img src="<?php echo esc_url( IPL_URL . 'assets/prod/kiosk.webp' ); ?>" alt="Clover Kiosk"></div>
        <div class="eq-top"><span class="tipo" data-i18n="eq_kiosk_tipo">Autoservicio</span><span class="reco" data-i18n="reco">Recomendado</span></div>
        <h3>Clover Kiosk</h3>
        <p data-i18n="eq_kiosk_d">Kiosco donde tus clientes ordenan y pagan solos, a su ritmo y sin hacer fila.</p>
        <ul data-i18n="eq_kiosk_l"><li>Terminal de pago e impresora integradas</li><li>Menú sincronizado con todos tus equipos</li><li>Pedidos para llevar y para comer en el local</li><li>Sugiere productos adicionales al ordenar</li></ul>
        <p class="ideal" data-i18n="eq_kiosk_i"><b>Ideal para:</b> restaurantes de comida rápida (quick service).</p>
      </article>
      <article class="equipo equipo-otro" data-fit="restaurante,tienda,servicios,taller">
        <div class="eq-foto"><img src="<?php echo esc_url( IPL_URL . 'assets/prod/n950.webp' ); ?>" alt="Newland N950"></div>
        <div class="eq-top"><span class="tipo" data-i18n="eq_n950_tipo">Terminal inteligente · Newland</span><span class="reco" data-i18n="reco">Recomendado</span></div>
        <h3>Newland N950</h3>
        <p data-i18n="eq_n950_d">Terminal compacta con funciones de punto de venta. Es nuestra opción fuera de Clover.</p>
        <ul data-i18n="eq_n950_l"><li>Maneja hasta 10 cuentas de comerciante en un solo equipo</li><li>Chip con PIN, contactless, banda magnética y billeteras digitales</li><li>Wi-Fi o 4G para cobrar donde estés</li><li>Divide cuentas, ajusta propinas y maneja menú e inventario</li><li>Se sincroniza con QuickBooks Online en tiempo real</li></ul>
        <p class="ideal" data-i18n="eq_n950_i"><b>Ideal para:</b> dueños con varios negocios o cuentas, y quienes llevan su contabilidad en QuickBooks.</p>
      </article>
    </div>
    <p class="filtro-nota" data-i18n="fitNote">Es una sugerencia inicial. José te recomienda el equipo exacto después de conocer tu negocio.</p>
    <div class="ofertas">
      <div class="oferta oferta-terminal oscuro" data-claim="terminal_gratis">
        <h3 data-i18n="offTermT">Terminal POS GRATIS para negocios que califican</h3>
        <p data-i18n="offTermD">Si tu negocio califica, el equipo no te cuesta.</p>
        <span class="cond" data-i18n="offTermC">Restricciones aplican. Consulta por tu caso.</span>
      </div>
      <?php if ( ipl_mostrar( 'papel' ) ) : ?>
      <div class="oferta oferta-papel" data-claim="papel_gratis">
        <h3 data-i18n="offPapT">Papel para recibos GRATIS</h3>
        <p data-i18n="offPapD">Te damos el papel para recibos sin costo durante los primeros 6 meses.</p>
      </div>
      <?php endif; ?>
    </div>
  </div>
</section>

<!-- 7. CASH DISCOUNT Y DUAL PRICING -->
<section class="sec sec-suave" id="precio-dual" aria-labelledby="h-dual" data-claim="cero_cargo">
  <div class="wrap">
    <div class="cab">
      <p class="eyebrow" data-i18n="dualEyebrow">Programas de precios</p>
      <h2 id="h-dual" data-i18n="dualTitle">Reduce tus costos de procesamiento con Cash Discount o Dual Pricing*</h2>
      <p data-i18n="dualLead">Son dos programas distintos. En ambos, el costo de procesar la tarjeta lo asume el cliente que paga con tarjeta, en lugar de tu negocio. Te explicamos cuál conviene a tu negocio y cuál aplica en tu estado.</p>
    </div>
    <div class="dual">
      <div class="programas">
        <article class="ticket">
          <p class="cab-t">Cash Discount</p>
          <p data-i18n="cdD">Tus precios publicados ya incluyen el costo de procesamiento. Quien paga en efectivo recibe un descuento en la caja.</p>
          <div class="fila"><span data-i18n="cdR1">Precio publicado</span><b data-i18n="cdV1">Incluye el costo de la tarjeta</b></div>
          <div class="fila"><span data-i18n="cdR2">Pago en efectivo</span><b data-i18n="cdV2">Recibe un descuento</b></div>
        </article>
        <article class="ticket">
          <p class="cab-t">Dual Pricing</p>
          <p data-i18n="dpD">Muestras dos precios para cada producto, uno en efectivo y otro con tarjeta, en el menú, las etiquetas y el recibo. El cliente elige cómo pagar.</p>
          <div class="fila"><span data-i18n="dpR1">Precio en efectivo</span><b data-i18n="dpV1">El más bajo</b></div>
          <div class="fila"><span data-i18n="dpR2">Precio con tarjeta</span><b data-i18n="dpV2">Incluye el costo de la tarjeta</b></div>
        </article>
      </div>
      <div class="dual-txt">
        <h3 data-i18n="mTitle">Lo que debes saber antes de activarlo</h3>
        <ul class="matices">
          <li><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 8v5M12 16v.5"/></svg><span data-i18n="m1">Son programas de precios, no una ley ni una obligación.</span></li>
          <li><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 8v5M12 16v.5"/></svg><span data-i18n="m2">Las reglas cambian según el estado y el tipo de tarjeta. Por ejemplo, no se puede cobrar un recargo (surcharge) a las tarjetas de débito.</span></li>
          <li><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 8v5M12 16v.5"/></svg><span data-i18n="m3">Tu negocio debe mostrar avisos claros en la entrada, en la caja y en el recibo.</span></li>
          <li><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 8v5M12 16v.5"/></svg><span data-i18n="m4">Antes de activarlo te explicamos qué aplica en tu estado y si conviene para tu negocio.</span></li>
        </ul>
        <p class="nota" data-i18n="dualFoot">*El ahorro depende del programa aprobado, de las reglas de tu estado y de cómo pagan tus clientes. Restricciones aplican.</p>
      </div>
    </div>
  </div>
</section>

<?php if ( ipl_mostrar( 'financiamiento' ) ) : ?>
<!-- 7b. FINANCIAMIENTO (proveedor externo: Funderial) -->
<section class="sec" id="financiamiento" aria-labelledby="h-fin">
  <div class="wrap fondos">
    <div class="fondos-txt">
      <p class="eyebrow">Business Funding</p>
      <h2 id="h-fin" data-i18n="finTitle">Financiamiento para tu negocio: hasta $500,000</h2>
      <p class="fondos-lead" data-i18n="finLead">Con PaySplit de Funderial puedes obtener hasta el 250% de tu volumen mensual de ventas con tarjeta, con respuesta en horas.</p>
      <ul class="fondos-ben">
        <li><b data-i18n="fb1t">Úsalo para lo que necesites</b><span data-i18n="fb1d">Marketing, reparaciones, inventario o expansión. Los fondos no tienen uso restringido.</span></li>
        <li><b data-i18n="fb2t">Pagas según lo que vendes</b><span data-i18n="fb2d">Se paga con una pequeña parte de tus ventas diarias con tarjeta. Si un día vendes poco o cierras, ese día no abonas.</span></li>
      </ul>
      <div class="requisitos">
        <p class="req-t" data-i18n="reqT">Requisitos para aplicar</p>
        <ul>
          <li data-i18n="req1">$5,000 al mes en ventas con tarjeta</li>
          <li data-i18n="req2">1 mes en operación</li>
          <li data-i18n="req3">Cualquier puntaje de crédito (FICO)</li>
        </ul>
      </div>
      <p class="fondos-nota" data-i18n="finNote">El financiamiento lo otorga Funderial, un proveedor externo, y está sujeto a su aprobación. Los montos, costos y condiciones dependen de cada negocio. Impulso Pay te ayuda con la solicitud.</p>
    </div>
    <aside class="fondos-cta oscuro" aria-label="Solicitar financiamiento">
      <p class="cta-t" data-i18n="finCtaT">Escanea y pide tu cotización gratis</p>
      <img src="<?php echo esc_url( IPL_URL . 'assets/qr.png' ); ?>" width="330" height="330" alt="Código QR para solicitar financiamiento en go.funderial.com/Colindres">
      <a class="btn btn-prim" href="https://go.funderial.com/Colindres" target="_blank" rel="noopener" data-track="funding" data-i18n="finBtn">Solicitar cotización gratis</a>
      <p class="cta-url">go.funderial.com/Colindres</p>
      <p class="cta-contact"><span data-i18n="finQ">¿Preguntas? Habla con José:</span><br><a href="tel:+16305516701" data-track="call">630-551-6701</a><br><a href="mailto:jose.colindres@impulsopay.com">jose.colindres@impulsopay.com</a></p>
    </aside>
  </div>
</section>

<?php endif; ?>

<?php if ( ipl_mostrar( 'servicios' ) ) : ?>
<!-- 7c. MÁS SERVICIOS (ATM y certificaciones con Lujan Business Services) -->
<section class="sec sec-suave" id="servicios" aria-labelledby="h-srv">
  <div class="wrap">
    <div class="cab">
      <h2 id="h-srv" data-i18n="srvTitle">Más servicios para tu negocio</h2>
      <p data-i18n="srvLead">Además de tus pagos, te ayudamos con otras cosas que tu negocio necesita.</p>
    </div>
    <div class="servicios">
      <?php if ( ipl_mostrar( 'atm' ) ) : ?>
      <article class="servicio" aria-labelledby="h-atm">
        <div class="serv-cab">
          <span class="serv-ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="2.5" width="14" height="19" rx="2"/><rect x="7.5" y="5" width="9" height="5.5" rx="1"/><path d="M8 13.5h1M11.5 13.5h1M15 13.5h1M8 16h1M11.5 16h1M15 16h1M9 19h6"/></svg></span>
          <h3 id="h-atm" data-i18n="atmT">Cajeros automáticos (ATM)</h3>
        </div>
        <p data-i18n="atmD">Instalamos un cajero ATM en tu negocio para que tus clientes saquen efectivo sin salir del local.</p>
        <ul class="serv-lista">
          <li><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg><span data-i18n="atm1">Instalación profesional y soporte continuo</span></li>
          <li><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg><span data-i18n="atm2">Varios modelos disponibles</span></li>
          <li><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg><span data-i18n="atm3">Reportes de tus transacciones</span></li>
          <li><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg><span data-i18n="atm4">Para restaurantes, tiendas, gasolineras y más</span></li>
        </ul>
        <p class="serv-cond" data-i18n="atmC">Disponibilidad, modelos y condiciones según tu negocio. Consulta por tu caso.</p>
        <a class="btn btn-sec btn-sm" href="https://wa.me/16305516701?text=Hola%2C%20quiero%20informaci%C3%B3n%20sobre%20cajeros%20ATM%20/%20Hi%2C%20I%20would%20like%20info%20about%20ATM%20machines%20%28impulsopay.com%29" target="_blank" rel="noopener" data-track="whatsapp"><span data-i18n="atmBtn">Preguntar por un ATM</span></a>
      </article>
      <?php endif; ?>
      <?php if ( ipl_mostrar( 'certificaciones' ) ) : ?>
      <article class="servicio" aria-labelledby="h-cer">
        <div class="serv-cab">
          <span class="serv-ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="9" r="6"/><path d="M9.5 9l1.8 1.8L14.8 7.3"/><path d="M8.5 14l-1.5 7.5 5-2.5 5 2.5-1.5-7.5"/></svg></span>
          <div><h3 id="h-cer" data-i18n="cerT">Certificaciones para restaurantes</h3><p class="serv-ali" data-i18n="cerAli">En alianza con Lujan Business Services</p></div>
        </div>
        <p data-i18n="cerD">Las certificaciones que tu restaurante y tu personal necesitan, con la ayuda de expertos.</p>
        <ul class="serv-lista">
          <li><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg><span data-i18n="cer1"><b>Food Handler:</b> para cocineros, meseros y todo el personal</span></li>
          <li><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg><span data-i18n="cer2"><b>Food Protection Manager:</b> para gerentes y supervisores</span></li>
          <li><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg><span data-i18n="cer3"><b>Seguridad alimentaria y alérgenos:</b> prevención de contaminación y manejo de alergias</span></li>
          <li><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg><span data-i18n="cer4"><b>ServSafe Alcohol:</b> servicio responsable de bebidas alcohólicas</span></li>
        </ul>
        <p class="serv-chip" data-i18n="cerLang">Clases en español e inglés</p>
        <p class="serv-cond"><span data-i18n="cerC">Los cursos los imparte Lujan Business Services. Costos y horarios según el curso.</span> <span data-i18n="srvTm">ServSafe es una marca registrada de National Restaurant Association.</span></p>
        <a class="btn btn-sec btn-sm" href="https://wa.me/16305516701?text=Hola%2C%20quiero%20informaci%C3%B3n%20sobre%20certificaciones%20para%20restaurantes%20/%20Hi%2C%20I%20would%20like%20info%20about%20restaurant%20certifications%20%28impulsopay.com%29" target="_blank" rel="noopener" data-track="whatsapp"><span data-i18n="cerBtn">Preguntar por certificaciones</span></a>
      </article>
      <?php endif; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- 8. PARA QUIÉN ES -->
<section class="sec" aria-labelledby="h-quien">
  <div class="wrap">
    <div class="cab">
      <p class="eyebrow" data-i18n="whoEyebrow">Para quién es</p>
      <h2 id="h-quien" data-i18n="whoTitle">Negocios que cobran todos los días y no tienen tiempo para enredos</h2>
    </div>
    <ul class="rubros">
      <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M7 3v8M5 3v4a2 2 0 0 0 4 0V3M7 11v10M17 3c-2 0-3 2-3 5s1 4 3 4v9"/></svg><span data-i18n="r1">Restaurantes</span><small data-claim="restaurantes" data-i18n="r1s">La mayoría de nuestros clientes</small></li>
      <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" aria-hidden="true"><path d="M3 9l1.5-5h15L21 9M3 9h18v2a3 3 0 0 1-6 0 3 3 0 0 1-6 0 3 3 0 0 1-6 0zM5 13v8h14v-8"/></svg><span data-i18n="r2">Tiendas</span></li>
      <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="6" cy="18" r="3"/><circle cx="18" cy="18" r="3"/><path d="M8 16 20 4M16 16 4 4"/></svg><span data-i18n="r3">Salones de belleza</span></li>
      <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" aria-hidden="true"><path d="M6 3h12l3 6-9 12L3 9z"/><path d="M3 9h18M9 3l3 18 3-18"/></svg><span data-i18n="r4">Joyerías</span></li>
      <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 0 0 5.4-5.4l-2.5 2.5-2.4-.6-.6-2.4z"/></svg><span data-i18n="r5">Talleres mecánicos</span></li>
    </ul>
    
  </div>
</section>

<!-- 9. SOBRE JOSÉ -->
<section class="sec sec-suave" id="jose" aria-labelledby="h-jose">
  <div class="wrap jose">
    <div class="foto">
      <img src="<?php echo esc_url( IPL_URL . 'assets/jose.webp' ); ?>" width="440" height="440" alt="José Colindres">
    </div>
    <div class="jose-txt">
      <p class="eyebrow" data-i18n="joseEyebrow">Quién te atiende</p>
      <h2 id="h-jose">José Colindres</h2>
      <p class="cargo" data-config="CARGO" data-claim="cargo"></p>
      <p data-i18n="joseP1">Soy José Colindres, asesor de procesamiento de pagos con 7 años de experiencia en Illinois. Ayudo a pequeños y medianos empresarios, especialmente restaurantes, a optimizar sus pagos con soluciones modernas, eficientes y económicas.</p>
      <p data-claim="clientes_70" data-i18n="joseP2">Actualmente respaldo a más de 70 negocios con un acompañamiento 100% personalizado: desde la instalación y capacitación hasta el soporte directo y continuo, en español o inglés.</p>
      <p data-i18n="joseP3">Con Impulso Pay, no solo obtienes equipos para aceptar tarjetas, sino a un aliado comprometido con reducir tus costos y hacer crecer tu negocio.</p>
      <div class="acciones">
        <a class="btn btn-prim" href="tel:+16305516701" data-track="call"><span data-i18n="ctaCall">Llamar ahora</span></a>
        <a class="btn btn-sec" href="https://wa.me/16305516701" target="_blank" rel="noopener" data-track="whatsapp"><span data-i18n="ctaWa">Escribir por WhatsApp</span></a>
      </div>
    </div>
  </div>
</section>

<!-- 10. TESTIMONIOS: se manejan desde WordPress (menú Testimonios). La sección aparece sola cuando hay al menos uno publicado con permiso. -->
<?php ipl_render_testimonios(); ?>

<!-- 11. PREGUNTAS FRECUENTES -->
<section class="sec" id="preguntas" aria-labelledby="h-faq">
  <div class="wrap">
    <div class="cab">
      <p class="eyebrow" data-i18n="faqEyebrow">Preguntas frecuentes</p>
      <h2 id="h-faq" data-i18n="faqTitle">Lo que más nos preguntan</h2>
    </div>
    <div class="faq">
      <details><summary data-i18n="faq_q1_q">¿Cuánto cuesta?</summary><div class="resp" data-i18n="faq_q1_a"><p>Depende de tu tipo de negocio, de tu volumen de ventas y de cómo te pagan tus clientes. Empezamos con un análisis GRATIS de tus costos de procesamiento y después te damos una propuesta por escrito, para que compares con calma.</p></div></details>
      <details data-claim="cero_cargo"><summary data-i18n="faq_q2_q">¿Qué son Cash Discount y Dual Pricing?</summary><div class="resp" data-i18n="faq_q2_a"><p>Son programas de precios en los que el cliente que paga con tarjeta asume el costo de procesamiento. Con Cash Discount, quien paga en efectivo recibe un descuento; con Dual Pricing, muestras un precio en efectivo y otro con tarjeta. No son una ley ni una obligación, y sus reglas cambian por estado y tipo de tarjeta. Te explicamos cuál conviene en tu caso.</p></div></details>
      <details data-claim="terminal_gratis"><summary data-i18n="faq_q3_q">¿La terminal POS es gratis?</summary><div class="resp" data-i18n="faq_q3_a"><p>Sí, para negocios que califican. Restricciones aplican; consulta por tu caso.</p></div></details>
      <?php if ( ipl_mostrar( 'financiamiento' ) ) : ?>
      <details><summary data-i18n="faq_q9_q">¿Ofrecen financiamiento para mi negocio?</summary><div class="resp" data-i18n="faq_q9_a"><p>Sí. A través de PaySplit de Funderial, un proveedor externo, puedes solicitar hasta $500,000 según tu volumen de ventas con tarjeta, y lo pagas con una pequeña parte de tus ventas diarias. Está sujeto a aprobación.</p><p><a href="#financiamiento">Ver requisitos y solicitar</a></p></div></details>
      <?php endif; ?>
      <details><summary data-i18n="faq_q4_q">¿Hay contrato de permanencia o cargo por cancelar?</summary><div class="resp" data-i18n="faq_q4_a"><p>Creemos que la confianza de nuestros clientes se gana con un excelente servicio, no con obligaciones innecesarias.</p><p>Por eso, trabajamos con total transparencia y te explicamos claramente las condiciones de tu servicio antes de firmar cualquier acuerdo.</p><p>Nuestro objetivo es que permanezcas con nosotros por los ahorros, la atención personalizada y la calidad de nuestro servicio.</p><p>Los términos de permanencia y posibles cargos por cancelación dependen del programa contratado.</p></div></details>
      <details><summary data-i18n="faq_q5_q">¿Cuánto tarda la instalación?</summary><div class="resp" data-i18n="faq_q5_a"><p>¡Queremos que tu negocio comience a procesar pagos lo antes posible!</p><p>Una vez aprobada tu solicitud y preparado tu equipo, coordinamos la instalación de acuerdo con tu disponibilidad.</p><p>Además, ofrecemos instalación, configuración y capacitación personalizada para que tú y tus empleados aprendan a utilizar el sistema correctamente.</p><p>No solamente instalamos tu equipo: te acompañamos durante todo el proceso.</p></div></details>
      <details><summary data-i18n="faq_q6_q">¿Cuándo recibo los depósitos de mis ventas?</summary><div class="resp" data-i18n="faq_q6_a"><p>Sabemos lo importante que es mantener un flujo de efectivo constante en tu negocio.</p><p>Por eso, ofrecemos opciones de depósito al siguiente día hábil (Next-Day Funding) para comerciantes elegibles, permitiéndote disponer de tus ingresos rápidamente.</p><p>Los tiempos de depósito pueden variar según el banco, el horario de cierre de transacciones y las condiciones de tu cuenta.</p><p>Nuestro objetivo es que recibas tu dinero de forma rápida, segura y confiable.</p></div></details>
      <details><summary data-i18n="faq_q7_q">Mi negocio está fuera de Illinois. ¿Me pueden atender?</summary><div class="resp" data-i18n="faq_q7_a"><p>¡Por supuesto! Aunque estamos ubicados en Illinois, nuestros servicios no se limitan a una sola ciudad o estado.</p><p>Atendemos negocios en diferentes partes de Estados Unidos, incluyendo Wisconsin, Indiana, Texas y Kentucky.</p><p>Ofrecemos asesoría, configuración de equipos, capacitación y asistencia a distancia, además de atención presencial en las áreas donde tenemos cobertura.</p><p>Sin importar dónde se encuentre tu negocio, queremos ayudarte a reducir costos y mejorar tu sistema de pagos.</p></div></details>
      <details><summary data-i18n="faq_q8_q">¿Me atienden en español?</summary><div class="resp" data-i18n="faq_q8_a"><p>¡Claro que sí! Hablamos tu idioma y entendemos las necesidades de los dueños de negocios hispanos.</p><p>Te ofrecemos atención personalizada en español o inglés, desde la primera consulta hasta la instalación y capacitación de tu equipo.</p><p>Te explicamos cada detalle de manera sencilla, incluyendo tarifas, funcionamiento del sistema y condiciones del servicio.</p><p>Porque creemos que el idioma nunca debe ser una barrera para hacer crecer tu negocio.</p></div></details>
    </div>
  </div>
</section>

<!-- 12. FORMULARIO -->
<section class="sec sec-suave" id="contacto" aria-labelledby="h-form">
  <div class="wrap contacto">
    <div class="contacto-info">
      <p class="eyebrow" data-i18n="formEyebrow">Análisis GRATIS</p>
      <h2 id="h-form" data-i18n="formTitle">Cuéntanos de tu negocio y te llamamos</h2>
      <p data-i18n="formLead" style="color:var(--texto-suave)">Déjanos tus datos y José te contacta para revisar tus costos de procesamiento. Si prefieres, llama o escribe ahora, 24/7.</p>
      <div class="dato"><span data-i18n="lblPhone">Teléfono y WhatsApp</span><a href="tel:+16305516701" data-track="call">630-551-6701</a></div>
      <div class="dato"><span data-i18n="lblEmail">Correo</span><a href="mailto:jose.colindres@impulsopay.com">jose.colindres@impulsopay.com</a></div>
      <div class="dato"><span data-i18n="lblArea">Zona</span><b data-i18n="areaVal">Todo Illinois</b></div>
      <div class="dato"><span data-i18n="hoursLabel">Horario:</span><b data-config="HORARIO"></b></div>
    </div>

    <!-- FORM_ENDPOINT: reemplazar en CONFIG (abajo) por la URL de Formspree, HubSpot, Google Apps Script, etc. -->
    <form id="formContacto" action="FORM_ENDPOINT" method="post" novalidate>
      <div class="campo"><label for="f-nombre" data-i18n="fName">Tu nombre</label><input id="f-nombre" name="nombre" autocomplete="name" required><span class="err" id="e-nombre"></span></div>
      <div class="campo"><label for="f-negocio" data-i18n="fBiz">Nombre del negocio</label><input id="f-negocio" name="negocio" autocomplete="organization" required><span class="err" id="e-negocio"></span></div>
      <div class="campo"><label for="f-tipo" data-i18n="fType">Tipo de negocio</label>
        <select id="f-tipo" name="tipo" required>
          <option value="" data-i18n="optChoose">Elige una opción</option>
          <option value="restaurante" data-i18n="optRest">Restaurante</option>
          <option value="tienda" data-i18n="optStore">Tienda</option>
          <option value="salon" data-i18n="optSalon">Salón de belleza</option>
          <option value="joyeria" data-i18n="optJewel">Joyería</option>
          <option value="taller" data-i18n="optShop">Taller mecánico</option>
          <option value="otro" data-i18n="optOther">Otro</option>
        </select><span class="err" id="e-tipo"></span></div>
      <div class="campo"><label for="f-ciudad" data-i18n="fCity">Ciudad</label><input id="f-ciudad" name="ciudad" autocomplete="address-level2" required><span class="err" id="e-ciudad"></span></div>
      <div class="campo"><label for="f-tel" data-i18n="fPhone">Teléfono</label><input id="f-tel" name="telefono" type="tel" inputmode="tel" autocomplete="tel" required><span class="err" id="e-tel"></span></div>
      <div class="campo"><label for="f-ventas" data-i18n="fSales">Ventas mensuales aproximadas</label>
        <select id="f-ventas" name="ventas" required>
          <option value="" data-i18n="optChoose">Elige una opción</option>
          <option value="<10k" data-i18n="v1">Menos de $10,000</option>
          <option value="10-30k" data-i18n="v2">$10,000 a $30,000</option>
          <option value="30-60k" data-i18n="v3">$30,000 a $60,000</option>
          <option value="60-100k" data-i18n="v4">$60,000 a $100,000</option>
          <option value=">100k" data-i18n="v5">Más de $100,000</option>
          <option value="nose" data-i18n="v6">No estoy seguro</option>
        </select><span class="err" id="e-ventas"></span></div>
      <input class="hp" type="text" name="empresa_web" id="f-hp" tabindex="-1" autocomplete="off" aria-hidden="true">
      <div class="full check" data-claim="consentimiento" data-nohide>
        <input type="checkbox" id="f-ok" name="consentimiento" required>
        <label for="f-ok" data-i18n="consent">Acepto que Impulso Pay me contacte por llamada, mensaje de texto o WhatsApp al número que di, sobre mi solicitud. Pueden aplicar tarifas de mensajes y datos. Puedo responder STOP para dejar de recibir mensajes.</label>
      </div>
      <span class="err full" id="e-ok"></span>
      <div class="full"><button class="btn btn-prim" type="submit" style="width:100%" data-i18n="fSubmit">Quiero mi análisis GRATIS</button></div>
      <div class="gracias" id="gracias" role="status" aria-live="polite" hidden></div>
    </form>
  </div>
</section>
</main>

<!-- 13. PIE DE PÁGINA -->
<footer class="oscuro">
  <div class="wrap">
    <div class="pie-cols">
      <div class="pie-marca">
        <img src="<?php echo esc_url( IPL_URL . 'assets/wordmark.webp' ); ?>" width="560" height="75" alt="Impulso Pay">
        <p data-i18n="tagline">Impulsa tu negocio. Simplifica tus pagos.</p>
        
      </div>
      <div>
        <h2 data-i18n="footContact">Contacto</h2>
        <ul>
          <li><a href="tel:+16305516701" data-track="call">630-551-6701</a></li>
          <li><a href="https://wa.me/16305516701" target="_blank" rel="noopener" data-track="whatsapp">WhatsApp</a></li>
          <li><a href="mailto:jose.colindres@impulsopay.com">jose.colindres@impulsopay.com</a></li>
        </ul>
      </div>
      <div>
        <h2 data-i18n="footArea">Zona</h2>
        <ul>
          <li data-i18n="areaVal">Todo Illinois</li>
          <li data-i18n="footStates">Clientes en IL, WI, IN, TX y KY</li>
          <li><span data-i18n="hoursLabel">Horario:</span> <span data-config="HORARIO"></span></li>
        </ul>
      </div>
    </div>
    <div class="legal">
      <?php $ipl_aviso = get_option( 'ipl_aviso_legal', '' ); if ( $ipl_aviso ) : ?><p><?php echo nl2br( esc_html( $ipl_aviso ) ); ?></p><?php endif; ?>
      <p data-i18n="tmNote">Clover y su logotipo son marcas registradas de Clover Network, LLC. El uso de Clover requiere un contrato de procesamiento (Merchant Processing Agreement).</p>
      <p><a href="<?php echo esc_url( ipl_legal_url( 'privacidad' ) ?: '#' ); ?>" data-i18n="privacy">Política de privacidad</a> · <a href="<?php echo esc_url( ipl_legal_url( 'terminos' ) ?: '#' ); ?>" data-i18n="terms">Términos y condiciones</a></p>
      <p>© <span id="anio">2026</span> <span data-config="BRAND_NAME"></span></p>
    </div>
  </div>
</footer>

<!-- Barra fija en móvil -->
<div class="barra-movil" aria-label="Contacto rápido">
  <a class="btn btn-prim" href="tel:+16305516701" data-track="call"><span data-i18n="mCall">Llamar</span></a>
  <a class="btn btn-sec" href="https://wa.me/16305516701" target="_blank" rel="noopener" data-track="whatsapp">WhatsApp</a>
</div>
<?php wp_footer(); ?>
</body>
</html>
