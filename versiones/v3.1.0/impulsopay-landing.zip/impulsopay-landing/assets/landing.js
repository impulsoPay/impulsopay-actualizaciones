/* Impulso Pay – idioma, filtro de equipos, formulario */
/* ================= CONFIGURACIÓN EDITABLE ================= */
const CONFIG = {
  BRAND_NAME: "Impulso Pay",
  HORARIO: "24/7",                            // confirmado por José (10 oct 2026)
  HORARIO_EN: "24/7",
  CARGO: "Asesor de confianza",
  CARGO_EN: "Trusted Advisor",
  FORM_ENDPOINT: "FORM_ENDPOINT",             // URL real del formulario; mientras diga FORM_ENDPOINT no se envía nada
  DRAFT_MODE: false                           // true = muestra [PENDIENTE]; false = OCULTA todo lo pendiente
};

/* ================= REGISTRO DE AFIRMACIONES =================
   estado: "aprobado" | "pendiente". Para aprobar una afirmación, cambia su estado.
   En DRAFT_MODE=false, todo elemento con data-claim pendiente se oculta.
   "aprobado (José)" = aprobado internamente; igual va en el paquete de revisión del procesador. */
const CLAIMS = {
  lema:            { texto: "Impulsa tu negocio. Simplifica tus pagos.", estado: "aprobado" },
  contacto:        { texto: "630-551-6701 · WhatsApp · jose.colindres@impulsopay.com", estado: "aprobado" },
  horario:         { texto: "Atención 24/7", estado: "aprobado", nota: "Confirmado por José" },
  zona:            { texto: "Todo Illinois; clientes en IL, WI, IN, TX, KY; abiertos a todo el país", estado: "aprobado" },
  idiomas:         { texto: "Atención en español e inglés", estado: "aprobado" },
  atencion:        { texto: "Instalación, capacitación y soporte continuo", estado: "aprobado" },
  analisis_gratis: { texto: "Análisis GRATIS de costos de procesamiento, propuesta por escrito", estado: "aprobado" },
  restaurantes:    { texto: "La mayoría de nuestros clientes son restaurantes", estado: "aprobado" },
  cargo:           { texto: "José Colindres, Asesor de confianza", estado: "aprobado" },
  clover_texto:    { texto: "Sistemas POS Clover (solo texto, sin logo)", estado: "aprobado", nota: "Aprobado (José); incluir en paquete de revisión" },
  clover_modelos:  { texto: "Compact, Mini, Station Solo, Flex, Flex Pocket, Kiosk (datos de fichas oficiales)", estado: "aprobado", nota: "Aprobado (José); incluir en paquete de revisión" },
  terminal_gratis: { texto: "Terminal POS GRATIS para negocios que califican. Restricciones aplican. Consulta por tu caso.", estado: "aprobado", nota: "Aprobado (José); incluir en paquete de revisión" },
  papel_gratis:    { texto: "Papel para recibos GRATIS por 6 meses", estado: "aprobado" },
  cero_cargo:      { texto: "Cash Discount y Dual Pricing, con matices", estado: "aprobado", nota: "Aprobado (José); confirmar qué programa(s) están autorizados" },
  consentimiento:  { texto: "Texto de consentimiento para llamadas y mensajes", estado: "aprobado" },
  clientes_70:     { texto: "Más de 70 negocios", estado: "aprobado", nota: "Confirmado por José" },
  financiamiento:  { texto: "PaySplit de Funderial: hasta $500,000, hasta 250% del volumen mensual, requisitos y pago diario (datos del flyer)", estado: "aprobado", nota: "Proveedor externo; sujeto a aprobación" },
  newland_n950:    { texto: "Newland N950 (datos del flyer)", estado: "aprobado" },
  experiencia:     { texto: "7 años de experiencia", estado: "aprobado", nota: "Dato de José" },
  faq_respuestas:  { texto: "Permanencia según programa, instalación coordinada, Next-Day Funding para comerciantes elegibles", estado: "aprobado", nota: "Texto de José" }
};

/* ================= TRADUCCIONES (EN) =================
   El español vive en el HTML; se guarda al cargar y se restaura al volver a ES. */
const EN = {
 "skip": "Skip to content",
 "draftBanner": "Draft mode: items marked [PENDING] will not be published until approved.",
 "tagline": "Grow your business. Simplify your payments.",
 "navHow": "How it works",
 "navSystems": "POS Systems",
 "navDual": "Cash Discount",
 "navFund": "Funding",
 "navSrv": "Services",
 "navFaq": "FAQ",
 "headerCta": "FREE Analysis",
 "heroEyebrow": "Merchant Services · Illinois",
 "heroTitle": "Accept card payments the <em>easy, fast and secure way.</em>",
 "heroLead": "Clover POS systems and credit card processing for restaurants, retail stores and small businesses, with direct support from José 24/7, in English or Spanish.",
 "ctaCall": "Call now",
 "ctaWa": "Message on WhatsApp",
 "heroNum": "Phone and WhatsApp:",
 "hoursLabel": "Hours:",
 "heroLema": "Grow your business. <b>Simplify your payments.</b>",
 "t1": "Personal support 24/7",
 "t2": "Serving all of Illinois",
 "t3": "English and Spanish",
 "t4": "Clover POS Systems",
 "t5": "Installation, training and ongoing support",
 "probEyebrow": "What we hear from business owners",
 "probTitle": "Credit card processing doesn’t have to be complicated",
 "p1a": "Fees you can’t trace",
 "p1b": "We explain every fee, line by line, before you sign.",
 "p2a": "Long statements that are hard to read",
 "p2b": "We give you a FREE processing cost analysis and show you exactly what you’re paying.",
 "p3a": "Slow support, or a number nobody answers",
 "p3b": "You call or text José directly, 24/7, and he follows up in person.",
 "ecTitle": "Do these statement terms look familiar?",
 "ecText": "These are common line items on a processing statement. Bring us yours and we’ll explain what each one means for you.",
 "howEyebrow": "How it works",
 "howTitle": "Get your business up and running in 4 simple steps",
 "s1t": "Consultation",
 "s1d": "Call or message us. We talk about your business, how you accept payments today and what you need.",
 "s2t": "FREE processing cost analysis",
 "s2d": "We review your statement and what you pay today, then give you a written proposal with no obligation.",
 "s3t": "Installation and training",
 "s3d": "José comes to your business, sets up the equipment and trains you and your staff.",
 "s4t": "Ongoing support",
 "s4d": "We stay in touch after installation. If something goes wrong, you call the same number, 24/7.",
 "eqEyebrow": "Terminals and POS systems",
 "eqTitle": "POS systems and terminals for every type of business",
 "eqLead": "We work with Clover systems and the Newland N950 terminal. From a countertop terminal to a self-service kiosk, we recommend equipment based on how you serve your customers and give you pricing in writing.",
 "fitLbl": "What type of business do you have?",
 "fitAll": "All",
 "fitRest": "Restaurant",
 "fitQsr": "Quick service",
 "fitRetail": "Retail or jewelry",
 "fitSalon": "Salon or services",
 "fitShop": "Auto shop",
 "swipe": "Swipe to see all devices →",
 "fitNote": "This is a starting suggestion. José recommends the exact equipment after getting to know your business.",
 "offTermT": "FREE POS terminal for qualifying businesses",
 "offTermD": "If your business qualifies, the equipment costs you nothing.",
 "offTermC": "Restrictions apply. Ask about your case.",
 "offPapT": "FREE receipt paper",
 "offPapD": "We provide receipt paper at no cost for your first 6 months.",
 "dualEyebrow": "Pricing programs",
 "dualTitle": "Lower your processing costs with Cash Discount or Dual Pricing*",
 "dualLead": "They are two different programs. In both, the cost of processing the card is covered by the customer who pays by card, instead of your business. We explain which one fits your business and which one applies in your state.",
 "cdD": "Your posted prices already include the processing cost. Customers who pay cash get a discount at checkout.",
 "cdR1": "Posted price",
 "cdV1": "Includes the card cost",
 "cdR2": "Cash payment",
 "cdV2": "Gets a discount",
 "dpD": "You show two prices for every item, one for cash and one for card, on the menu, the price tags and the receipt. The customer chooses how to pay.",
 "dpR1": "Cash price",
 "dpV1": "The lower price",
 "dpR2": "Card price",
 "dpV2": "Includes the card cost",
 "mTitle": "What to know before you turn it on",
 "m1": "These are pricing programs, not a law or a requirement.",
 "m2": "Rules vary by state and card type. For example, a surcharge can never be applied to debit cards.",
 "m3": "Your business must post clear notices at the entrance, at checkout and on the receipt.",
 "m4": "Before turning it on, we explain what applies in your state and whether it makes sense for you.",
 "dualFoot": "*Savings depend on the approved program, your state’s rules and how your customers pay. Restrictions apply.",
 "finTitle": "Business funding for your company: up to $500,000",
 "finLead": "With PaySplit from Funderial you can get up to 250% of your monthly card processing volume, with an answer within hours.",
 "fb1t": "Use it for anything you need",
 "fb1d": "Marketing, repairs, inventory or expansion. The funds are unrestricted.",
 "fb2t": "Repay as you sell",
 "fb2d": "Repay with a small portion of your daily card sales. On slow or closed days, you don’t pay toward your balance.",
 "reqT": "Requirements to apply",
 "req1": "$5,000 per month in card sales",
 "req2": "1 month in business",
 "req3": "Any credit score (FICO)",
 "finNote": "Funding is provided by Funderial, a third-party provider, and is subject to its approval. Amounts, costs and terms depend on each business. Impulso Pay helps you with the application.",
 "finCtaT": "Scan to get your free quote",
 "finBtn": "Get a free quote",
 "finQ": "Questions? Talk to José:",
 "whoEyebrow": "Who it’s for",
 "whoTitle": "Businesses that take payments every day and have no time for hassle",
 "r1": "Restaurants",
 "r1s": "Most of our clients",
 "r2": "Retail stores",
 "r3": "Beauty salons",
 "r4": "Jewelry stores",
 "r5": "Auto repair shops",
 "joseEyebrow": "Who you’ll work with",
 "joseP1": "I’m José Colindres, a payment processing advisor with 7 years of experience in Illinois. I help small and mid-sized business owners, especially restaurants, optimize their payments with modern, efficient and affordable solutions.",
 "joseP2": "Today I support more than 70 businesses with 100% personalized service: from installation and training to direct, ongoing support, in English or Spanish.",
 "joseP3": "With Impulso Pay, you don’t just get equipment to accept cards. You get a partner committed to lowering your costs and growing your business.",
 "testiTitle": "What our clients say",
 "faqEyebrow": "FAQ",
 "faqTitle": "Questions we hear most",
 "formEyebrow": "FREE analysis",
 "formTitle": "Tell us about your business and we’ll call you",
 "formLead": "Leave your details and José will reach out to review your processing costs. Or call or message now, 24/7.",
 "lblPhone": "Phone and WhatsApp",
 "lblEmail": "Email",
 "lblArea": "Area",
 "areaVal": "All of Illinois",
 "fName": "Your name",
 "fBiz": "Business name",
 "fType": "Type of business",
 "optChoose": "Choose one",
 "optRest": "Restaurant",
 "optStore": "Retail store",
 "optSalon": "Beauty salon",
 "optJewel": "Jewelry store",
 "optShop": "Auto repair shop",
 "optOther": "Other",
 "fCity": "City",
 "fPhone": "Phone",
 "fSales": "Approximate monthly sales",
 "v1": "Under $10,000",
 "v2": "$10,000 to $30,000",
 "v3": "$30,000 to $60,000",
 "v4": "$60,000 to $100,000",
 "v5": "Over $100,000",
 "v6": "Not sure",
 "consent": "I agree that Impulso Pay may contact me by call, text message or WhatsApp at the number I provided about my request. Message and data rates may apply. Reply STOP to opt out.",
 "fSubmit": "Get my FREE analysis",
 "footContact": "Contact",
 "footArea": "Area",
 "footStates": "Clients in IL, WI, IN, TX and KY",
 "tmNote": "Clover and its logo are registered trademarks of Clover Network, LLC. Use of Clover requires a Merchant Processing Agreement.",
 "privacy": "Privacy policy",
 "terms": "Terms and conditions",
 "mCall": "Call",
 "reco": "Recommended",
 "idealLbl": "Best for:",
 "promoLink": "Learn more",
 "testiEyebrow": "Testimonials",
 "srvTitle": "More services for your business",
 "srvLead": "Beyond payments, we help with other things your business needs.",
 "atmT": "ATM machines",
 "atmD": "We install an ATM in your business so your customers can get cash without leaving.",
 "atm1": "Professional installation and ongoing support",
 "atm2": "Several models available",
 "atm3": "Transaction reports",
 "atm4": "For restaurants, stores, gas stations and more",
 "atmC": "Availability, models and terms depend on your business. Ask about your case.",
 "atmBtn": "Ask about an ATM",
 "cerT": "Restaurant certifications",
 "cerAli": "In partnership with Lujan Business Services",
 "cerD": "The certifications your restaurant and your staff need, with help from experts.",
 "cer1": "<b>Food Handler:</b> for cooks, servers and all staff",
 "cer2": "<b>Food Protection Manager:</b> for managers and supervisors",
 "cer3": "<b>Food safety and allergens:</b> contamination prevention and allergy management",
 "cer4": "<b>ServSafe Alcohol:</b> responsible alcohol service",
 "cerLang": "Classes in Spanish and English",
 "cerC": "Courses are taught by Lujan Business Services. Cost and schedule depend on the course.",
 "cerBtn": "Ask about certifications",
 "srvTm": "ServSafe is a registered trademark of the National Restaurant Association.",
 "eq_compact_tipo": "Countertop · Payments only",
 "eq_compact_d": "A countertop payment terminal built to take payments fast, with no hassle.",
 "eq_compact_l": "<li>3.6\" touchscreen and physical PIN pad</li><li>Built-in thermal printer</li><li>Chip, contactless and swipe</li><li>Wi-Fi, LAN and LTE</li>",
 "eq_compact_i": "<b>Best for:</b> salons, auto shops and businesses that only need to take payments.",
 "eq_mini_tipo": "Countertop · Full POS",
 "eq_mini_d": "A full point of sale in a small device, so you free up counter space.",
 "eq_mini_l": "<li>7\" touchscreen and built-in receipt printer</li><li>Chip, contactless and swipe</li><li>Inventory with categories, modifiers and variants</li><li>Ethernet, Wi-Fi, Bluetooth and 4G</li>",
 "eq_mini_i": "<b>Best for:</b> retail stores, jewelry stores, coffee shops and salons.",
 "eq_flex_tipo": "Handheld · With printer",
 "eq_flex_d": "A handheld POS to take payment where your customer is, with the power of a larger device.",
 "eq_flex_l": "<li>5.99\" touchscreen and built-in printer</li><li>Wi-Fi and 4G/LTE with lithium-ion battery</li><li>Fingerprint login</li><li>Swipe, dip, tap and mobile wallets</li>",
 "eq_flex_i": "<b>Best for:</b> pay-at-table, line-busting, sidewalk sales and events.",
 "eq_pocket_tipo": "Handheld · Ultralight",
 "eq_pocket_d": "The lightest Flex. Fits in a back pocket or an apron.",
 "eq_pocket_l": "<li>6\" display and barcode/QR scanner</li><li>Weighs 0.9 lb (Flex 3 weighs 1.2 lb)</li><li>Receipts by email or SMS (no printer)</li><li>Fire orders right from the table</li>",
 "eq_pocket_i": "<b>Best for:</b> servers and tableside service.",
 "eq_solo_tipo": "Full station",
 "eq_solo_d": "A large-screen POS to run your entire business from one system.",
 "eq_solo_l": "<li>Clover Dining: front and back of house in sync</li><li>Inventory, returns and exchanges</li><li>Sales reports and employee management</li><li>Online ordering</li>",
 "eq_solo_i": "<b>Best for:</b> busy restaurants and stores with several employees.",
 "eq_duo_tipo": "Full station · Dual screens",
 "eq_duo_d": "A full POS with one screen for you and one for your customer, so they can see their total and pay from their side.",
 "eq_duo_l": "<li>Customer-facing screen: contactless payment and contact info and preferences</li><li>Clover Dining: front and back of house in sync</li><li>Inventory, returns and exchanges</li><li>Sales reports and employee management</li>",
 "eq_duo_i": "<b>Best for:</b> busy restaurants and stores that want a faster checkout.",
 "eq_kiosk_tipo": "Self-service",
 "eq_kiosk_d": "A kiosk where customers order and pay on their own, at their own pace, without waiting in line.",
 "eq_kiosk_l": "<li>Built-in payment terminal and printer</li><li>Menu synced across all your devices</li><li>Pick-up and dine-in orders</li><li>Suggests add-ons while ordering</li>",
 "eq_kiosk_i": "<b>Best for:</b> quick service restaurants.",
 "eq_n950_tipo": "Smart terminal · Newland",
 "eq_n950_d": "A compact terminal with point-of-sale features. Our option outside of Clover.",
 "eq_n950_l": "<li>Manage up to 10 merchant accounts on one device</li><li>EMV chip & PIN, contactless, magstripe and digital wallets</li><li>Wi-Fi or 4G to take payments on the go</li><li>Split bills, adjust tips, manage menu and inventory</li><li>Real-time sync with QuickBooks Online</li>",
 "eq_n950_i": "<b>Best for:</b> owners with several businesses or accounts, and anyone who keeps their books in QuickBooks.",
 "faq_q1_q": "How much does it cost?",
 "faq_q1_a": "<p>It depends on your type of business, your monthly volume and how your customers pay. We start with a FREE processing cost analysis, then give you a written proposal so you can compare calmly.</p>",
 "faq_q2_q": "What are Cash Discount and Dual Pricing?",
 "faq_q2_a": "<p>They are pricing programs where customers who pay by card cover the processing cost. With Cash Discount, cash customers get a discount; with Dual Pricing, you show a cash price and a card price. They are not a law or a requirement, and the rules vary by state and card type. We’ll tell you which one makes sense for you.</p>",
 "faq_q3_q": "Is the POS terminal free?",
 "faq_q3_a": "<p>Yes, for qualifying businesses. Restrictions apply; ask about your case.</p>",
 "faq_q9_q": "Do you offer business funding?",
 "faq_q9_a": "<p>Yes. Through PaySplit from Funderial, a third-party provider, you can apply for up to $500,000 based on your card sales volume, and repay with a small portion of your daily sales. Subject to approval.</p><p><a href=\"#financiamiento\">See requirements and apply</a></p>",
 "faq_q4_q": "Is there a long-term contract or a cancellation fee?",
 "faq_q4_a": "<p>We believe our clients’ trust is earned through excellent service, not unnecessary obligations.</p><p>That’s why we work with full transparency and clearly explain the terms of your service before you sign any agreement.</p><p>Our goal is for you to stay with us because of the savings, the personal attention and the quality of our service.</p><p>Contract terms and any early termination fees depend on the program you choose.</p>",
 "faq_q5_q": "How long does installation take?",
 "faq_q5_a": "<p>We want your business accepting payments as soon as possible!</p><p>Once your application is approved and your equipment is ready, we schedule the installation around your availability.</p><p>We also provide personalized installation, setup and training so you and your employees learn to use the system correctly.</p><p>We don’t just install your equipment: we support you through the entire process.</p>",
 "faq_q6_q": "When do I receive deposits from my sales?",
 "faq_q6_a": "<p>We know how important steady cash flow is for your business.</p><p>That’s why we offer Next-Day Funding options for eligible merchants, so you can access your revenue quickly.</p><p>Deposit times may vary depending on your bank, your batch close time and your account terms.</p><p>Our goal is for you to receive your money quickly, securely and reliably.</p>",
 "faq_q7_q": "My business is outside Illinois. Can you help?",
 "faq_q7_a": "<p>Absolutely! Although we’re based in Illinois, our services aren’t limited to one city or state.</p><p>We serve businesses in different parts of the United States, including Wisconsin, Indiana, Texas and Kentucky.</p><p>We offer remote consulting, equipment setup, training and support, plus in-person service in the areas we cover.</p><p>Wherever your business is, we want to help you lower costs and improve your payment system.</p>",
 "faq_q8_q": "Do you offer service in Spanish?",
 "faq_q8_a": "<p>Of course! We speak your language and understand the needs of Hispanic business owners.</p><p>We offer personalized service in Spanish or English, from your first consultation through installation and staff training.</p><p>We explain every detail in simple terms, including rates, how the system works and the terms of service.</p><p>Because language should never be a barrier to growing your business.</p>"
};
/* Datos que se cambian desde WordPress (Ajustes → Impulso Pay) */
if (window.IPL) {
  ["HORARIO", "HORARIO_EN", "CARGO", "CARGO_EN"].forEach(k => { const v = window.IPL[k.toLowerCase()]; if (v) CONFIG[k] = v; });
  if (window.IPL.i18n) Object.assign(EN, window.IPL.i18n);
}
const MSG = {
  es:{ req:"Completa este campo.", tel:"Escribe un teléfono de 10 dígitos.", ok:"Marca la casilla para que podamos contactarte.",
       sent:"¡Gracias! Recibimos tus datos. José te contactará pronto. Si es urgente, llama al 630-551-6701.",
       preview:"Vista previa: el formulario todavía no está conectado (FORM_ENDPOINT), así que no se envió nada. Para contactar a José llama al 630-551-6701.",
       fail:"No pudimos enviar el formulario. Llama o escribe al 630-551-6701.", pend:"[PENDIENTE]" },
  en:{ req:"Please fill out this field.", tel:"Enter a 10-digit phone number.", ok:"Check the box so we can contact you.",
       sent:"Thank you! We received your details. José will contact you soon. If it’s urgent, call 630-551-6701.",
       preview:"Preview: the form isn’t connected yet (FORM_ENDPOINT), so nothing was sent. To reach José, call 630-551-6701.",
       fail:"We couldn’t send the form. Please call or text 630-551-6701.", pend:"[PENDING]" }
};

let LANG = "es";
const ES = {};
document.querySelectorAll("[data-i18n]").forEach(el => { const k = el.dataset.i18n; if (!(k in ES)) ES[k] = el.innerHTML; });

function applyConfig(){
  document.querySelectorAll("[data-config]").forEach(el => {
    const k = el.dataset.config;
    el.textContent = (LANG === "en" && CONFIG[k + "_EN"]) ? CONFIG[k + "_EN"] : CONFIG[k];
  });
}
function applyClaims(){
  document.getElementById("avisoBorrador").hidden = !CONFIG.DRAFT_MODE;
  document.querySelectorAll(".pend").forEach(b => b.remove());
  document.querySelectorAll("[data-claim]").forEach(el => {
    const c = CLAIMS[el.dataset.claim];
    const pendiente = !c || c.estado !== "aprobado";
    if (!pendiente) { el.hidden = false; return; }
    if (!CONFIG.DRAFT_MODE) { if (!el.hasAttribute("data-nohide")) el.hidden = true; return; }
    if (el.hasAttribute("data-nobadge")) return;
    const b = document.createElement("span");
    b.className = "pend"; b.textContent = MSG[LANG].pend;
    if (c && c.nota) b.title = c.nota;
    const target = el.matches("details") ? el.querySelector("summary")
                 : el.matches(".cab") ? el.querySelector("h2")
                 : el.matches(".equipos") ? el.querySelector(".equipo h3")
                 : el.matches(".check") ? el.querySelector("label")
                 : el.matches("section") ? el.querySelector("h2")
                 : el.matches(".oferta") ? el.querySelector("h3")
                 : el;
    target.appendChild(b);
  });
}
function setLang(l){
  LANG = l;
  document.documentElement.lang = l;
  document.querySelectorAll("[data-i18n]").forEach(el => {
    const k = el.dataset.i18n;
    const v = l === "en" ? EN[k] : ES[k];
    if (v !== undefined) el.innerHTML = v;
  });
  document.querySelectorAll(".lang button").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.lang === l)));
  applyConfig(); applyClaims();
  try { localStorage.setItem("ip_lang", l); } catch(e){}
}
document.querySelectorAll(".lang button").forEach(b => b.addEventListener("click", () => setLang(b.dataset.lang)));

/* Analítica: dispara eventos si GA4 o Meta Pixel están activos */
function track(evento, datos){
  try { if (window.gtag) gtag("event", evento, datos || {}); } catch(e){}
  try { if (window.fbq) fbq("track", evento === "generate_lead" ? "Lead" : "Contact", datos || {}); } catch(e){}
}
document.querySelectorAll("[data-track]").forEach(a => a.addEventListener("click", () => track({call:"click_llamar",whatsapp:"click_whatsapp",funding:"click_financiamiento"}[a.dataset.track] || "click")));

/* Formulario */
const form = document.getElementById("formContacto");
const gracias = document.getElementById("gracias");
function marcar(id, errId, msg){
  const el = document.getElementById(id), er = document.getElementById(errId);
  el.setAttribute("aria-invalid", msg ? "true" : "false");
  if (msg) el.setAttribute("aria-describedby", errId); else el.removeAttribute("aria-describedby");
  er.textContent = msg || "";
  return !msg;
}
form.addEventListener("submit", async (ev) => {
  ev.preventDefault();
  const m = MSG[LANG]; let ok = true, primero = null;
  [["f-nombre","e-nombre"],["f-negocio","e-negocio"],["f-tipo","e-tipo"],["f-ciudad","e-ciudad"],["f-ventas","e-ventas"]].forEach(([i,e]) => {
    const v = document.getElementById(i).value.trim();
    if (!marcar(i, e, v ? "" : m.req)) { ok = false; primero = primero || i; }
  });
  const tel = document.getElementById("f-tel").value.replace(/\D/g, "");
  if (!marcar("f-tel", "e-tel", (tel.length === 10 || (tel.length === 11 && tel[0] === "1")) ? "" : m.tel)) { ok = false; primero = primero || "f-tel"; }
  if (!marcar("f-ok", "e-ok", document.getElementById("f-ok").checked ? "" : m.ok)) { ok = false; primero = primero || "f-ok"; }
  if (!ok) { document.getElementById(primero).focus(); return; }
  if (document.getElementById("f-hp").value) return; // trampa anti-spam

  const endpoint = (window.IPL && window.IPL.endpoint) || CONFIG.FORM_ENDPOINT;
  const conectado = /^https?:\/\//.test(endpoint);
  if (!conectado) { gracias.textContent = m.preview; gracias.hidden = false; return; }
  const boton = form.querySelector('button[type="submit"]');
  boton.disabled = true;
  try {
    const datos = new FormData(form);
    datos.append("idioma", LANG);
    const r = await fetch(endpoint, { method: "POST", body: datos, headers: { "Accept": "application/json" } });
    if (!r.ok) throw new Error(r.status);
    track("generate_lead", { tipo: document.getElementById("f-tipo").value, ventas: document.getElementById("f-ventas").value });
    form.reset(); gracias.textContent = m.sent; gracias.hidden = false;
  } catch(e) { gracias.textContent = m.fail; gracias.hidden = false; }
  boton.disabled = false;
});

/* Filtro de equipos por tipo de negocio */
document.querySelectorAll(".filtro button").forEach(b => b.addEventListener("click", () => {
  const f = b.dataset.fit;
  document.querySelectorAll(".filtro button").forEach(x => x.setAttribute("aria-pressed", String(x === b)));
  document.querySelectorAll(".equipo[data-fit]").forEach(c => {
    const ok = f === "todos" || c.dataset.fit.split(",").includes(f);
    c.classList.toggle("atenuado", !ok);
    c.classList.toggle("recomendado", ok && f !== "todos");
  });
  /* En celular (carrusel), lleva al primer equipo recomendado */
  const cont = document.querySelector(".equipos");
  const first = document.querySelector(".equipo.recomendado") || document.querySelector(".equipo[data-fit]");
  if (cont && first && cont.scrollWidth > cont.clientWidth) cont.scrollTo({ left: first.offsetLeft - cont.offsetLeft - 20, behavior: "smooth" });
}));

document.getElementById("anio").textContent = new Date().getFullYear();
let inicial = "es";
try { const g = localStorage.getItem("ip_lang"); if (g === "en" || g === "es") inicial = g; } catch(e){}
if (location.hash === "#en") inicial = "en";
setLang(inicial);
