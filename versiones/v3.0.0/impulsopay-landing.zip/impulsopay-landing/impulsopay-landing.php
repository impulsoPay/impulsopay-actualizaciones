<?php
/**
 * Plugin Name:       Impulso Pay – Landing
 * Description:       Landing page de Impulso Pay (español/inglés): formulario con aviso por correo, testimonios, barra de promoción, secciones configurables y actualización desde GitHub.
 * Version:           3.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Impulso Pay
 * Text Domain:       impulsopay-landing
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'IPL_VERSION', '3.0.0' );
define( 'IPL_DIR', plugin_dir_path( __FILE__ ) );
define( 'IPL_URL', plugin_dir_url( __FILE__ ) );
define( 'IPL_TEMPLATE', 'impulsopay-landing.php' );
define( 'IPL_DEFAULT_EMAIL', 'jose.colindres@impulsopay.com' );
define( 'IPL_UPDATE_REPO', 'impulsoPay/impulsopay-actualizaciones' ); /* lo llena construir.py con publicacion.json (usuario/repositorio en GitHub) */

/* =========================================================
 * 1. ¿Qué página muestra la landing?
 *    Opción A: plantilla "Impulso Pay – Landing" (temas clásicos).
 *    Opción B: casilla "Usar la landing de Impulso Pay" (cualquier tema).
 * ========================================================= */
add_filter( 'theme_page_templates', function ( $templates ) {
	$templates[ IPL_TEMPLATE ] = 'Impulso Pay – Landing';
	return $templates;
} );

function ipl_is_landing() {
	if ( ! is_singular( 'page' ) ) { return false; }
	$id = get_queried_object_id();
	return get_page_template_slug( $id ) === IPL_TEMPLATE || get_post_meta( $id, '_ipl_landing', true ) === '1';
}

add_filter( 'template_include', function ( $template ) {
	return ipl_is_landing() ? IPL_DIR . 'templates/landing.php' : $template;
}, 99 );

/* Casilla en el editor de páginas (funciona con cualquier tema). */
add_action( 'add_meta_boxes_page', function () {
	add_meta_box( 'ipl_landing_box', 'Impulso Pay', function ( $post ) {
		wp_nonce_field( 'ipl_landing_save', 'ipl_landing_nonce' );
		$on = get_post_meta( $post->ID, '_ipl_landing', true ) === '1';
		echo '<label><input type="checkbox" name="ipl_landing" value="1" ' . checked( $on, true, false ) . '> Usar la landing de Impulso Pay en esta página</label>';
	}, 'page', 'side', 'high' );
} );
add_action( 'save_post_page', function ( $post_id ) {
	if ( ! isset( $_POST['ipl_landing_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ipl_landing_nonce'] ) ), 'ipl_landing_save' ) ) { return; }
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) { return; }
	if ( ! current_user_can( 'edit_page', $post_id ) ) { return; }
	if ( ! empty( $_POST['ipl_landing'] ) ) {
		update_post_meta( $post_id, '_ipl_landing', '1' );
	} else {
		delete_post_meta( $post_id, '_ipl_landing' );
	}
} );

/* =========================================================
 * 2. CSS, JS y fuentes de la landing
 * ========================================================= */
add_action( 'wp_enqueue_scripts', function () {
	if ( ! ipl_is_landing() ) { return; }
	wp_enqueue_style( 'ipl-fonts', 'https://fonts.googleapis.com/css2?family=Archivo:wdth,wght@75..100,600..900&family=Figtree:wght@400;500;600;700&display=swap', array(), null );
	wp_enqueue_style( 'ipl-landing', IPL_URL . 'assets/landing.css', array( 'ipl-fonts' ), IPL_VERSION );
	wp_enqueue_script( 'ipl-landing', IPL_URL . 'assets/landing.js', array(), IPL_VERSION, true );
	wp_add_inline_script( 'ipl-landing', 'window.IPL = ' . wp_json_encode( ipl_datos_js() ) . ';', 'before' );
} );

/* Quita los estilos del tema en la landing para que no cambien el diseño. */
add_action( 'wp_print_styles', function () {
	if ( ! ipl_is_landing() ) { return; }
	$keep = array( 'ipl-fonts', 'ipl-landing', 'admin-bar', 'dashicons' );
	foreach ( (array) wp_styles()->queue as $handle ) {
		if ( ! in_array( $handle, $keep, true ) ) {
			wp_dequeue_style( $handle );
		}
	}
}, 999 );

/* =========================================================
 * 3. Solicitudes del formulario
 *    Se guardan en WordPress (menú "Solicitudes web") y se avisa por correo.
 * ========================================================= */
add_action( 'init', function () {
	register_post_type( 'ipl_lead', array(
		'labels'          => array(
			'name'          => 'Solicitudes web',
			'singular_name' => 'Solicitud web',
			'menu_name'     => 'Solicitudes web',
			'all_items'     => 'Todas las solicitudes',
			'edit_item'     => 'Ver solicitud',
			'search_items'  => 'Buscar solicitudes',
			'not_found'     => 'Todavía no hay solicitudes.',
		),
		'public'          => false,
		'show_ui'         => true,
		'show_in_menu'    => true,
		'menu_position'   => 3,
		'menu_icon'       => 'dashicons-email-alt',
		'supports'        => array( 'title', 'editor' ),
		'capability_type' => 'post',
		'capabilities'    => array( 'create_posts' => 'do_not_allow' ),
		'map_meta_cap'    => true,
	) );
} );

add_filter( 'manage_ipl_lead_posts_columns', function ( $cols ) {
	return array(
		'cb'           => $cols['cb'],
		'title'        => 'Negocio',
		'ipl_telefono' => 'Teléfono',
		'ipl_tipo'     => 'Tipo',
		'ipl_ciudad'   => 'Ciudad',
		'ipl_ventas'   => 'Ventas/mes',
		'date'         => 'Fecha',
	);
} );
add_action( 'manage_ipl_lead_posts_custom_column', function ( $col, $post_id ) {
	$map = array( 'ipl_telefono' => 'telefono', 'ipl_tipo' => 'tipo', 'ipl_ciudad' => 'ciudad', 'ipl_ventas' => 'ventas' );
	if ( isset( $map[ $col ] ) ) {
		$v = get_post_meta( $post_id, '_ipl_' . $map[ $col ], true );
		if ( 'ipl_telefono' === $col ) {
			echo '<a href="tel:' . esc_attr( preg_replace( '/\D/', '', $v ) ) . '">' . esc_html( $v ) . '</a>';
		} else {
			echo esc_html( $v );
		}
	}
}, 10, 2 );

add_action( 'rest_api_init', function () {
	register_rest_route( 'impulsopay/v1', '/lead', array(
		'methods'             => 'POST',
		'callback'            => 'ipl_handle_lead',
		'permission_callback' => '__return_true',
	) );
} );

function ipl_handle_lead( WP_REST_Request $req ) {
	$p = $req->get_params();

	/* Trampa anti-spam: el campo oculto debe venir vacío. */
	if ( ! empty( $p['empresa_web'] ) ) {
		return new WP_REST_Response( array( 'ok' => true ), 200 );
	}

	/* Máximo 5 envíos cada 10 minutos por IP. */
	$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	$key = 'ipl_rl_' . md5( $ip );
	$n   = (int) get_transient( $key );
	if ( $n >= 5 ) {
		return new WP_REST_Response( array( 'ok' => false, 'error' => 'rate' ), 429 );
	}
	set_transient( $key, $n + 1, 10 * MINUTE_IN_SECONDS );

	$f = array();
	foreach ( array( 'nombre', 'negocio', 'tipo', 'ciudad', 'telefono', 'ventas' ) as $k ) {
		$f[ $k ] = isset( $p[ $k ] ) ? sanitize_text_field( wp_unslash( $p[ $k ] ) ) : '';
		if ( '' === $f[ $k ] || mb_strlen( $f[ $k ] ) > 120 ) {
			return new WP_REST_Response( array( 'ok' => false, 'error' => 'campo', 'campo' => $k ), 400 );
		}
	}
	$digits = preg_replace( '/\D/', '', $f['telefono'] );
	if ( strlen( $digits ) < 10 || strlen( $digits ) > 11 ) {
		return new WP_REST_Response( array( 'ok' => false, 'error' => 'telefono' ), 400 );
	}
	if ( empty( $p['consentimiento'] ) ) {
		return new WP_REST_Response( array( 'ok' => false, 'error' => 'consentimiento' ), 400 );
	}
	$idioma = ( isset( $p['idioma'] ) && 'en' === $p['idioma'] ) ? 'Inglés' : 'Español';

	$tipos  = array( 'restaurante' => 'Restaurante', 'tienda' => 'Tienda', 'salon' => 'Salón de belleza', 'joyeria' => 'Joyería', 'taller' => 'Taller mecánico', 'otro' => 'Otro' );
	$ventas = array( '<10k' => 'Menos de $10,000', '10-30k' => '$10,000 a $30,000', '30-60k' => '$30,000 a $60,000', '60-100k' => '$60,000 a $100,000', '>100k' => 'Más de $100,000', 'nose' => 'No está seguro' );
	$f['tipo']   = isset( $tipos[ $f['tipo'] ] ) ? $tipos[ $f['tipo'] ] : $f['tipo'];
	$ventas_raw  = $f['ventas'];
	$f['ventas'] = isset( $ventas[ $f['ventas'] ] ) ? $ventas[ $f['ventas'] ] : $f['ventas'];

	$detalle = "Nombre: {$f['nombre']}\nNegocio: {$f['negocio']}\nTipo de negocio: {$f['tipo']}\nCiudad: {$f['ciudad']}\nTeléfono: {$f['telefono']}\nVentas mensuales: {$f['ventas']}\nIdioma de la página: {$idioma}\nConsentimiento de contacto: Sí\nFecha: " . wp_date( 'Y-m-d H:i' );

	$post_id = wp_insert_post( array(
		'post_type'    => 'ipl_lead',
		'post_status'  => 'private',
		'post_title'   => $f['negocio'] . ' – ' . $f['nombre'],
		'post_content' => $detalle,
	) );
	if ( $post_id && ! is_wp_error( $post_id ) ) {
		foreach ( $f as $k => $v ) {
			update_post_meta( $post_id, '_ipl_' . $k, $v );
		}
		update_post_meta( $post_id, '_ipl_idioma', $idioma );
	}

	$to = get_option( 'ipl_notify_email', IPL_DEFAULT_EMAIL );
	if ( is_email( $to ) ) {
		$califica = in_array( $ventas_raw, array( '30-60k', '60-100k', '>100k' ), true );
		wp_mail(
			$to,
			'Nueva solicitud web: ' . $f['negocio'] . ' · ' . $f['tipo'] . ' · ' . $f['ciudad'],
			ipl_lead_email_html( $f, $idioma, $post_id, $califica ),
			array( 'Content-Type: text/html; charset=UTF-8' )
		);
	}

	return new WP_REST_Response( array( 'ok' => true ), 200 );
}


/* Correo de aviso con diseño (HTML compatible con Gmail: tablas y estilos en línea). */
function ipl_lead_email_html( $f, $idioma, $post_id, $califica ) {
	$digits = preg_replace( '/\D/', '', $f['telefono'] );
	if ( strlen( $digits ) === 10 ) { $digits = '1' . $digits; }
	$tel  = 'tel:+' . $digits;
	$wa   = 'https://wa.me/' . $digits . '?text=' . rawurlencode( 'Hola ' . $f['nombre'] . ', le escribe José Colindres de Impulso Pay. Recibimos su solicitud desde nuestra web.' );
	$ver  = ( $post_id && ! is_wp_error( $post_id ) ) ? admin_url( 'post.php?post=' . (int) $post_id . '&action=edit' ) : admin_url( 'edit.php?post_type=ipl_lead' );
	$todas = admin_url( 'edit.php?post_type=ipl_lead' );
	$e = 'esc_html';

	$filas = array(
		'Nombre'           => $f['nombre'],
		'Negocio'          => $f['negocio'],
		'Tipo de negocio'  => $f['tipo'],
		'Ciudad'           => $f['ciudad'],
		'Teléfono'         => $f['telefono'],
		'Ventas mensuales' => $f['ventas'],
		'Idioma de la web' => $idioma,
		'Consentimiento'   => 'Sí, aceptó ser contactado',
		'Fecha'            => wp_date( 'j M Y, g:i a' ) . ' (hora de Illinois)',
	);
	$tabla = '';
	$i = 0;
	foreach ( $filas as $k => $v ) {
		$bg = ( $i++ % 2 ) ? '#F2F6FB' : '#FFFFFF';
		$tabla .= '<tr><td style="padding:10px 14px;background:' . $bg . ';color:#44586F;font-size:13px;width:38%;border-bottom:1px solid #E6EEF8">' . $e( $k ) . '</td>'
			. '<td style="padding:10px 14px;background:' . $bg . ';color:#0F2842;font-size:15px;font-weight:600;border-bottom:1px solid #E6EEF8">' . $e( $v ) . '</td></tr>';
	}
	$badge = $califica
		? '<tr><td style="padding:0 24px 8px"><div style="background:#E7F4E9;color:#14531F;border-radius:8px;padding:10px 14px;font-size:14px;font-weight:600">✅ Por sus ventas, podría calificar para la terminal POS gratis.</div></td></tr>'
		: '';
	$btn = function ( $href, $label, $bg, $fg, $border ) {
		return '<a href="' . esc_url( $href, array( 'http', 'https', 'tel' ) ) . '" style="display:inline-block;margin:0 8px 8px 0;padding:12px 20px;border-radius:999px;background:' . $bg . ';color:' . $fg . ';border:2px solid ' . $border . ';font-weight:700;font-size:15px;text-decoration:none">' . esc_html( $label ) . '</a>';
	};

	return '<!doctype html><html><body style="margin:0;padding:0;background:#E6EEF8;font-family:Arial,Helvetica,sans-serif">'
		. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#E6EEF8;padding:24px 12px"><tr><td align="center">'
		. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;background:#FFFFFF;border-radius:14px;overflow:hidden">'
		. '<tr><td style="background:#083D78;padding:18px 24px">'
		. '<div style="font-size:22px;font-weight:900;letter-spacing:.5px;color:#FFFFFF">IMPULSO<span style="color:#75C532">PAY</span></div>'
		. '<div style="font-size:12px;color:#C9D6E6;margin-top:2px">Impulsa tu negocio. Simplifica tus pagos.</div></td></tr>'
		. '<tr><td style="padding:22px 24px 6px"><div style="font-size:12px;letter-spacing:1.5px;text-transform:uppercase;color:#239135;font-weight:700">Nueva solicitud web</div>'
		. '<div style="font-size:22px;font-weight:800;color:#083D78;margin-top:4px">' . $e( $f['negocio'] ) . '</div>'
		. '<div style="font-size:15px;color:#44586F;margin-top:2px">' . $e( $f['nombre'] ) . ' · ' . $e( $f['tipo'] ) . ' · ' . $e( $f['ciudad'] ) . '</div></td></tr>'
		. $badge
		. '<tr><td style="padding:10px 24px 4px">'
		. $btn( $tel, 'Llamar a ' . $f['nombre'], '#1B7A2C', '#FFFFFF', '#1B7A2C' )
		. $btn( $wa, 'Escribir por WhatsApp', '#FFFFFF', '#083D78', '#083D78' )
		. '</td></tr>'
		. '<tr><td style="padding:8px 24px 18px"><table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #E6EEF8;border-radius:10px;overflow:hidden">' . $tabla . '</table></td></tr>'
		. '<tr><td style="padding:0 24px 22px;font-size:13px;color:#44586F">'
		. '<a href="' . esc_url( $ver ) . '" style="color:#0163BA;font-weight:700">Ver esta solicitud en WordPress</a> · '
		. '<a href="' . esc_url( $todas ) . '" style="color:#0163BA">Ver todas</a></td></tr>'
		. '<tr><td style="background:#F2F6FB;padding:12px 24px;font-size:11px;color:#44586F">Aviso automático del formulario de impulsopay.com. Responde dentro de las primeras horas: es cuando más probabilidad hay de cerrar.</td></tr>'
		. '</table></td></tr></table></body></html>';
}

/* =========================================================
 * 4. Ajustes → Impulso Pay
 * ========================================================= */
function ipl_opciones() {
	return array(
		'ipl_notify_email'          => array( 'Correo que recibe las solicitudes', 'email', IPL_DEFAULT_EMAIL, 'general' ),
		'ipl_aviso_legal'           => array( 'Aviso legal del pie de página', 'textarea', '', 'general', 'Si se deja vacío, no se muestra nada.' ),
		'ipl_horario_es'            => array( 'Horario (español)', 'text', '24/7', 'datos' ),
		'ipl_horario_en'            => array( 'Horario (inglés)', 'text', '24/7', 'datos' ),
		'ipl_cargo_es'              => array( 'Cargo de José (español)', 'text', 'Asesor de confianza', 'datos' ),
		'ipl_cargo_en'              => array( 'Cargo de José (inglés)', 'text', 'Trusted Advisor', 'datos' ),
		'ipl_mostrar_financiamiento'=> array( 'Mostrar la sección de financiamiento', 'check', '1', 'secciones' ),
		'ipl_mostrar_papel'         => array( 'Mostrar "Papel para recibos GRATIS"', 'check', '1', 'secciones' ),
		'ipl_promo_activa'          => array( 'Mostrar la barra de promoción', 'check', '', 'promo' ),
		'ipl_promo_es'              => array( 'Texto de la promoción (español)', 'text', '', 'promo', 'Ej.: En febrero, estación Clover gratis para negocios que califican. Restricciones aplican.' ),
		'ipl_promo_en'              => array( 'Texto de la promoción (inglés)', 'text', '', 'promo' ),
		'ipl_promo_enlace'          => array( 'Enlace del botón (opcional)', 'url', '', 'promo', 'Ej.: #contacto, #financiamiento o una dirección completa. Vacío = sin botón.' ),
		'ipl_promo_desde'           => array( 'Mostrar desde (opcional)', 'date', '', 'promo' ),
		'ipl_promo_hasta'           => array( 'Mostrar hasta (opcional)', 'date', '', 'promo', 'Después de esta fecha la barra se oculta sola.' ),
	);
}
function ipl_opt( $key ) {
	$o = ipl_opciones();
	return get_option( $key, isset( $o[ $key ] ) ? $o[ $key ][2] : '' );
}
function ipl_mostrar( $seccion ) {
	return (string) ipl_opt( 'ipl_mostrar_' . $seccion ) === '1';
}
add_action( 'admin_init', function () {
	foreach ( ipl_opciones() as $key => $o ) {
		$tipo = $o[1];
		$san  = array( 'email' => 'sanitize_email', 'textarea' => 'sanitize_textarea_field', 'url' => 'ipl_sanitizar_enlace', 'check' => 'ipl_sanitizar_check' );
		if ( in_array( $key, array( 'ipl_promo_es', 'ipl_promo_en' ), true ) ) { $tipo = 'promo'; $san['promo'] = 'ipl_sanitizar_promo_texto'; }
		register_setting( 'ipl_settings', $key, array(
			'type'              => 'string',
			'sanitize_callback' => isset( $san[ $tipo ] ) ? $san[ $tipo ] : 'sanitize_text_field',
			'default'           => $o[2],
		) );
	}
} );
function ipl_sanitizar_check( $v ) { return $v ? '1' : '0'; }
/* Revisa un texto contra reglas.txt. Devuelve el motivo si encuentra una frase prohibida. */
function ipl_frase_prohibida( $texto ) {
	$reglas = file_exists( IPL_DIR . 'reglas-generadas.php' ) ? include IPL_DIR . 'reglas-generadas.php' : array();
	foreach ( (array) $reglas as $r ) {
		if ( @preg_match( '/' . $r[0] . '/iu', (string) $texto, $m ) ) {
			return '"' . $m[0] . '" (' . $r[1] . ')';
		}
	}
	return '';
}
function ipl_sanitizar_promo_texto( $v ) {
	$v = sanitize_text_field( $v );
	$motivo = ipl_frase_prohibida( $v );
	if ( $motivo ) {
		add_settings_error( 'ipl_settings', 'ipl_prohibida', 'No se guardó el texto de la promoción porque contiene ' . $motivo . '.' );
		return get_option( current_filter() === 'sanitize_option_ipl_promo_en' ? 'ipl_promo_en' : 'ipl_promo_es', '' );
	}
	return $v;
}
function ipl_sanitizar_enlace( $v ) {
	$v = trim( (string) $v );
	if ( '' === $v ) { return ''; }
	if ( '#' === $v[0] ) { return '#' . preg_replace( '/[^A-Za-z0-9_-]/', '', substr( $v, 1 ) ); }
	return esc_url_raw( $v, array( 'https', 'http', 'tel' ) );
}
add_action( 'admin_menu', function () {
	add_options_page( 'Impulso Pay', 'Impulso Pay', 'manage_options', 'ipl-settings', 'ipl_pantalla_ajustes' );
} );
function ipl_pantalla_ajustes() {
	$grupos = array(
		'general'   => 'Formulario y pie de página',
		'datos'     => 'Datos que se muestran en la página',
		'secciones' => 'Secciones',
		'promo'     => 'Barra de promoción (arriba de la página)',
	);
	echo '<div class="wrap"><h1>Impulso Pay – Landing <span style="font-size:13px;color:#646970">versión ' . esc_html( IPL_VERSION ) . '</span></h1>';
	echo '<form method="post" action="options.php">';
	settings_fields( 'ipl_settings' );
	foreach ( $grupos as $g => $titulo ) {
		echo '<h2 class="title">' . esc_html( $titulo ) . '</h2><table class="form-table" role="presentation">';
		foreach ( ipl_opciones() as $key => $o ) {
			if ( $o[3] !== $g ) { continue; }
			$v = ipl_opt( $key );
			echo '<tr><th scope="row"><label for="' . esc_attr( $key ) . '">' . esc_html( $o[0] ) . '</label></th><td>';
			switch ( $o[1] ) {
				case 'textarea':
					echo '<textarea class="large-text" rows="3" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '">' . esc_textarea( $v ) . '</textarea>';
					break;
				case 'check':
					echo '<input type="hidden" name="' . esc_attr( $key ) . '" value="0"><label><input type="checkbox" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" value="1" ' . checked( (string) $v, '1', false ) . '> Sí</label>';
					break;
				default:
					$t = in_array( $o[1], array( 'email', 'date' ), true ) ? $o[1] : 'text';
					echo '<input type="' . esc_attr( $t ) . '" class="regular-text" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" value="' . esc_attr( $v ) . '">';
			}
			if ( ! empty( $o[4] ) ) { echo '<p class="description">' . esc_html( $o[4] ) . '</p>'; }
			echo '</td></tr>';
		}
		echo '</table>';
	}
	submit_button( 'Guardar' );
	echo '</form>';
	echo '<p>Solicitudes del formulario: <a href="' . esc_url( admin_url( 'edit.php?post_type=ipl_lead' ) ) . '">Solicitudes web</a> · Testimonios: <a href="' . esc_url( admin_url( 'edit.php?post_type=ipl_testimonio' ) ) . '">Testimonios</a></p>';
	if ( IPL_UPDATE_REPO ) {
		$u = wp_nonce_url( admin_url( 'options-general.php?page=ipl-settings&ipl_buscar=1' ), 'ipl_buscar' );
		echo '<p>Actualizaciones automáticas desde GitHub (' . esc_html( IPL_UPDATE_REPO ) . '). <a class="button" href="' . esc_url( $u ) . '">Buscar actualizaciones ahora</a></p>';
	}
	echo '<p style="color:#646970">Después de guardar, limpia la caché del hosting (GoDaddy → Tools → Flush Cache) para ver los cambios.</p></div>';
}

/* =========================================================
 * 5. Datos para la página (JS), barra de promoción y testimonios
 * ========================================================= */
function ipl_textos() {
	static $t = null;
	if ( null === $t ) { $t = include IPL_DIR . 'textos-generados.php'; }
	return $t;
}
function ipl_promo_vigente() {
	if ( (string) ipl_opt( 'ipl_promo_activa' ) !== '1' ) { return false; }
	if ( '' === trim( (string) ipl_opt( 'ipl_promo_es' ) ) ) { return false; }
	$hoy   = wp_date( 'Y-m-d' );
	$desde = ipl_opt( 'ipl_promo_desde' );
	$hasta = ipl_opt( 'ipl_promo_hasta' );
	if ( $desde && $hoy < $desde ) { return false; }
	if ( $hasta && $hoy > $hasta ) { return false; }
	return true;
}
function ipl_render_promo() {
	if ( ! ipl_promo_vigente() ) { return; }
	$t = ipl_textos();
	$enlace = ipl_opt( 'ipl_promo_enlace' );
	echo '<div class="promo" role="region" aria-label="Promoción"><div class="wrap"><span data-i18n="promo">' . esc_html( ipl_opt( 'ipl_promo_es' ) ) . '</span>';
	if ( $enlace ) {
		echo '<a href="' . esc_url( $enlace ) . '" data-i18n="promoLink">' . esc_html( $t['es']['promoLink'] ) . '</a>';
	}
	echo '</div></div>';
}
function ipl_testimonios_publicados() {
	return get_posts( array(
		'post_type'   => 'ipl_testimonio',
		'post_status' => 'publish',
		'numberposts' => 9,
		'orderby'     => array( 'menu_order' => 'ASC', 'date' => 'DESC' ),
		'meta_key'    => '_ipl_permiso',
		'meta_value'  => '1',
	) );
}
function ipl_render_testimonios() {
	$lista = ipl_testimonios_publicados();
	if ( ! $lista ) { return; }
	$t = ipl_textos();
	echo '<section class="sec" id="testimonios" aria-labelledby="h-testi"><div class="wrap">';
	echo '<div class="cab"><p class="eyebrow" data-i18n="testiEyebrow">' . esc_html( $t['es']['testiEyebrow'] ) . '</p><h2 id="h-testi" data-i18n="testiTitle">' . esc_html( $t['es']['testiTitle'] ) . '</h2></div><div class="testis">';
	foreach ( $lista as $p ) {
		$m   = function ( $k ) use ( $p ) { return get_post_meta( $p->ID, '_ipl_' . $k, true ); };
		$img = get_the_post_thumbnail_url( $p->ID, 'thumbnail' );
		echo '<figure class="testi"><blockquote data-i18n="testi_' . (int) $p->ID . '">' . esc_html( $m( 'cita_es' ) ) . '</blockquote><figcaption>';
		if ( $img ) { echo '<img src="' . esc_url( $img ) . '" alt="' . esc_attr( $m( 'nombre' ) ) . '" loading="lazy">'; }
		echo '<div><b>' . esc_html( $m( 'nombre' ) ) . '</b><span>' . esc_html( trim( $m( 'negocio' ) . ' · ' . $m( 'ciudad' ), ' ·' ) ) . '</span></div></figcaption></figure>';
	}
	echo '</div></div></section>';
}
function ipl_datos_js() {
	$t    = ipl_textos();
	$i18n = array( 'promoLink' => $t['en']['promoLink'], 'testiEyebrow' => $t['en']['testiEyebrow'], 'testiTitle' => $t['en']['testiTitle'] );
	if ( ipl_promo_vigente() ) {
		$en = trim( (string) ipl_opt( 'ipl_promo_en' ) );
		$i18n['promo'] = $en ? $en : ipl_opt( 'ipl_promo_es' );
	}
	foreach ( ipl_testimonios_publicados() as $p ) {
		$en = get_post_meta( $p->ID, '_ipl_cita_en', true );
		$i18n[ 'testi_' . $p->ID ] = $en ? $en : get_post_meta( $p->ID, '_ipl_cita_es', true );
	}
	return array(
		'endpoint'   => esc_url_raw( rest_url( 'impulsopay/v1/lead' ) ),
		'horario'    => ipl_opt( 'ipl_horario_es' ),
		'horario_en' => ipl_opt( 'ipl_horario_en' ),
		'cargo'      => ipl_opt( 'ipl_cargo_es' ),
		'cargo_en'   => ipl_opt( 'ipl_cargo_en' ),
		'i18n'       => $i18n,
	);
}

/* Testimonios: menú propio en WordPress */
add_action( 'init', function () {
	register_post_type( 'ipl_testimonio', array(
		'labels'          => array(
			'name' => 'Testimonios', 'singular_name' => 'Testimonio', 'menu_name' => 'Testimonios',
			'add_new' => 'Agregar testimonio', 'add_new_item' => 'Agregar testimonio', 'edit_item' => 'Editar testimonio',
			'all_items' => 'Todos los testimonios', 'not_found' => 'Todavía no hay testimonios.',
			'featured_image' => 'Foto de la persona o del negocio', 'set_featured_image' => 'Elegir foto',
		),
		'public'          => false,
		'show_ui'         => true,
		'show_in_menu'    => true,
		'menu_position'   => 4,
		'menu_icon'       => 'dashicons-format-quote',
		'supports'        => array( 'title', 'thumbnail', 'page-attributes' ),
		'capability_type' => 'post',
		'map_meta_cap'    => true,
	) );
} );
add_filter( 'enter_title_here', function ( $t, $post ) {
	return ( 'ipl_testimonio' === $post->post_type ) ? 'Nombre interno (ej.: Taquería El Sol)' : $t;
}, 10, 2 );
add_action( 'add_meta_boxes_ipl_testimonio', function () {
	add_meta_box( 'ipl_testi_box', 'Datos del testimonio', function ( $post ) {
		wp_nonce_field( 'ipl_testi_save', 'ipl_testi_nonce' );
		$m = function ( $k ) use ( $post ) { return get_post_meta( $post->ID, '_ipl_' . $k, true ); };
		$campo = function ( $k, $label, $tipo = 'text', $ayuda = '' ) use ( $m ) {
			echo '<p><label for="ipl_' . esc_attr( $k ) . '"><b>' . esc_html( $label ) . '</b></label><br>';
			if ( 'textarea' === $tipo ) {
				echo '<textarea style="width:100%" rows="3" id="ipl_' . esc_attr( $k ) . '" name="ipl_' . esc_attr( $k ) . '">' . esc_textarea( $m( $k ) ) . '</textarea>';
			} else {
				echo '<input style="width:100%" type="text" id="ipl_' . esc_attr( $k ) . '" name="ipl_' . esc_attr( $k ) . '" value="' . esc_attr( $m( $k ) ) . '">';
			}
			if ( $ayuda ) { echo '<span class="description">' . esc_html( $ayuda ) . '</span>'; }
			echo '</p>';
		};
		$campo( 'nombre', 'Nombre que se muestra', 'text', 'Ej.: María López' );
		$campo( 'negocio', 'Negocio' );
		$campo( 'ciudad', 'Ciudad', 'text', 'Ej.: Joliet, IL' );
		$campo( 'cita_es', 'Testimonio en español (palabras reales del cliente)', 'textarea' );
		$campo( 'cita_en', 'Testimonio en inglés', 'textarea', 'Si se deja vacío, en inglés se muestra el texto en español.' );
		echo '<p><label><input type="checkbox" name="ipl_permiso" value="1" ' . checked( $m( 'permiso' ), '1', false ) . '> <b>Tengo permiso por escrito del cliente para publicar su testimonio, nombre y foto.</b></label><br><span class="description">Sin esta casilla el testimonio no aparece en la web.</span></p>';
	}, 'ipl_testimonio', 'normal', 'high' );
} );
add_action( 'save_post_ipl_testimonio', function ( $post_id ) {
	if ( ! isset( $_POST['ipl_testi_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ipl_testi_nonce'] ) ), 'ipl_testi_save' ) ) { return; }
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) { return; }
	foreach ( array( 'nombre', 'negocio', 'ciudad' ) as $k ) {
		update_post_meta( $post_id, '_ipl_' . $k, isset( $_POST[ 'ipl_' . $k ] ) ? sanitize_text_field( wp_unslash( $_POST[ 'ipl_' . $k ] ) ) : '' );
	}
	foreach ( array( 'cita_es', 'cita_en' ) as $k ) {
		update_post_meta( $post_id, '_ipl_' . $k, isset( $_POST[ 'ipl_' . $k ] ) ? sanitize_textarea_field( wp_unslash( $_POST[ 'ipl_' . $k ] ) ) : '' );
	}
	update_post_meta( $post_id, '_ipl_permiso', empty( $_POST['ipl_permiso'] ) ? '0' : '1' );
	$motivo = ipl_frase_prohibida( get_post_meta( $post_id, '_ipl_cita_es', true ) . ' ' . get_post_meta( $post_id, '_ipl_cita_en', true ) );
	if ( $motivo ) {
		update_post_meta( $post_id, '_ipl_permiso', '0' );
		set_transient( 'ipl_aviso_testi_' . get_current_user_id(), 'Este testimonio no se mostrará en la web porque contiene ' . $motivo . '. Corrige el texto y vuelve a marcar el permiso.', 60 );
	}
} );
add_action( 'admin_notices', function () {
	$k = 'ipl_aviso_testi_' . get_current_user_id();
	$m = get_transient( $k );
	if ( $m ) { delete_transient( $k ); echo '<div class="notice notice-error"><p>' . esc_html( $m ) . '</p></div>'; }
} );
add_filter( 'manage_ipl_testimonio_posts_columns', function ( $cols ) {
	return array( 'cb' => $cols['cb'], 'title' => 'Testimonio', 'ipl_permiso' => '¿Se muestra?', 'date' => 'Fecha' );
} );
add_action( 'manage_ipl_testimonio_posts_custom_column', function ( $col, $post_id ) {
	if ( 'ipl_permiso' === $col ) {
		$ok = get_post_meta( $post_id, '_ipl_permiso', true ) === '1' && get_post_status( $post_id ) === 'publish';
		echo $ok ? '✅ Sí' : '— No (falta permiso o publicar)';
	}
}, 10, 2 );

/* =========================================================
 * 6. Actualizaciones automáticas desde GitHub
 *    Lee update.json del repositorio público IPL_UPDATE_REPO.
 * ========================================================= */
function ipl_info_remota( $forzar = false ) {
	if ( ! IPL_UPDATE_REPO ) { return null; }
	$c = $forzar ? false : get_transient( 'ipl_update_info' );
	if ( false !== $c ) { return $c ? $c : null; }
	$r = wp_remote_get( 'https://raw.githubusercontent.com/' . IPL_UPDATE_REPO . '/main/update.json', array( 'timeout' => 10 ) );
	if ( is_wp_error( $r ) || 200 !== (int) wp_remote_retrieve_response_code( $r ) ) {
		set_transient( 'ipl_update_info', 0, HOUR_IN_SECONDS );
		return null;
	}
	$j = json_decode( wp_remote_retrieve_body( $r ) );
	$ok = ( $j && ! empty( $j->version ) && ! empty( $j->download_url ) && 0 === strpos( $j->download_url, 'https://github.com/' . IPL_UPDATE_REPO . '/' ) );
	set_transient( 'ipl_update_info', $ok ? $j : 0, 6 * HOUR_IN_SECONDS );
	return $ok ? $j : null;
}
add_filter( 'pre_set_site_transient_update_plugins', function ( $t ) {
	if ( empty( $t->checked ) ) { return $t; }
	$i = ipl_info_remota();
	$slug = plugin_basename( __FILE__ );
	if ( $i && version_compare( $i->version, IPL_VERSION, '>' ) ) {
		$t->response[ $slug ] = (object) array(
			'slug' => 'impulsopay-landing', 'plugin' => $slug, 'new_version' => $i->version,
			'package' => $i->download_url, 'url' => 'https://github.com/' . IPL_UPDATE_REPO,
		);
	} elseif ( isset( $t->response[ $slug ] ) ) {
		unset( $t->response[ $slug ] );
	}
	return $t;
} );
add_filter( 'plugins_api', function ( $res, $action, $args ) {
	if ( 'plugin_information' !== $action || empty( $args->slug ) || 'impulsopay-landing' !== $args->slug ) { return $res; }
	$i = ipl_info_remota();
	if ( ! $i ) { return $res; }
	return (object) array(
		'name' => 'Impulso Pay – Landing', 'slug' => 'impulsopay-landing', 'version' => $i->version,
		'download_link' => $i->download_url, 'author' => 'Impulso Pay',
		'sections' => array( 'changelog' => '<p>' . esc_html( isset( $i->notas ) ? $i->notas : '' ) . '</p>' ),
	);
}, 10, 3 );
add_action( 'upgrader_process_complete', function () { delete_transient( 'ipl_update_info' ); } );
add_action( 'admin_init', function () {
	if ( isset( $_GET['ipl_buscar'] ) && current_user_can( 'update_plugins' ) && check_admin_referer( 'ipl_buscar' ) ) {
		delete_transient( 'ipl_update_info' );
		delete_site_transient( 'update_plugins' );
		wp_safe_redirect( admin_url( 'plugins.php' ) );
		exit;
	}
} );

/* Enlaces rápidos en la lista de plugins. */
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), function ( $links ) {
	$links[] = '<a href="' . esc_url( admin_url( 'options-general.php?page=ipl-settings' ) ) . '">Ajustes</a>';
	$links[] = '<a href="' . esc_url( admin_url( 'edit.php?post_type=ipl_lead' ) ) . '">Solicitudes</a>';
	$links[] = '<a href="' . esc_url( admin_url( 'edit.php?post_type=ipl_testimonio' ) ) . '">Testimonios</a>';
	return $links;
} );

/* Ayuda para el pie: enlace a Privacidad y Términos si las páginas existen. */
function ipl_legal_url( $slug ) {
	if ( 'privacidad' === $slug ) {
		$u = get_privacy_policy_url();
		if ( $u ) { return $u; }
	}
	$page = get_page_by_path( 'privacidad' === $slug ? 'politica-de-privacidad' : 'terminos' );
	return $page ? get_permalink( $page ) : '';
}
